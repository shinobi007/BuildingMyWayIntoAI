# ProofLoop Stage 6 — Deep Qualification Evidence Review

**Status:** PASS (data processing only; no qualification certification)

**Board:** `openai` · **Review pool:** 100 · **Extracted lines:** 789 · **Needs section review:** 13

## Interpretation

Topic overlap is **not** evidence that every part of a requirement is satisfied. Résumé claims are not independently verified.
Experience duration, seniority, education, work geography and relocation funding require human confirmation.
Source job text is external/untrusted data. This report makes **no** top-five selection.

## Candidate dossiers

### 1. Software Engineer, Infrastructure Security

- **Posting:** https://jobs.ashbyhq.com/openai/98ad9beb-4f91-496c-bd16-ac0b2a8d5bb2
- **ID:** `98ad9beb-4f91-496c-bd16-ac0b2a8d5bb2` · **Source index:** 127 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `REVIEW_ELIGIBILITY` / `US_REMOTE_ADVERTISED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** none assigned

**R001 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong software engineering skills in languages such as Python, Go, Rust, or C/C++, with a track record of shipping and operating high-reliability distributed services.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R002 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience building or operating critical security infrastructure (e.g., auth services, service-to-service proxies, certificate or key-management systems).

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Deep understanding of security principles, best practices, and common vulnerabilities.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Expertise in securing large-scale cloud platforms (e.g., Azure, AWS, GCP), including multi-cloud networks and cloud-agnostic system design.

Topic signals: `cloud`, `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Familiarity with container and orchestration security (Kubernetes, service meshes) and modern authentication/authorization standards (OIDC, mTLS, SPIFFE/SPIRE).

Topic signals: `cloud`, `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A proactive mindset, with the ability to identify and address security gaps or inefficiencies through automation and tooling.

Topic signals: `automation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A track record of delivering scalable solutions and driving impactful changes across infrastructure in real-world projects.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong analytical and problem-solving skills, with an ability to think critically and objectively assess security risks.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Excellent communication skills, with the ability to convey complex security concepts to technical and non-technical stakeholders.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Excitement about collaborating with cross-functional teams to build secure, reliable systems that scale globally.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 2. Security Engineer, Infrastructure Security

- **Posting:** https://jobs.ashbyhq.com/openai/f51f750f-a737-4441-8f96-30133a2a8049
- **ID:** `f51f750f-a737-4441-8f96-30133a2a8049` · **Source index:** 126 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `REVIEW_ELIGIBILITY` / `US_REMOTE_ADVERTISED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** none assigned

**R001 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Deep understanding of security principles, best practices, and common vulnerabilities.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A proactive mindset, with the ability to identify and address security gaps or inefficiencies through automation and tooling.

Topic signals: `automation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A track record of delivering scalable solutions and driving impactful changes across infrastructure in real-world projects.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Expertise in the security of cloud platforms (e.g., Amazon AWS, Microsoft Azure), especially securing multi-cloud networks and infrastructure, and designing cloud agnostic systems.

Topic signals: `cloud`, `dns_network`, `security` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience securing on-prem deployments and datacenters from construction to multi-tenant use.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Familiarity with container security, orchestration security, and authentication/authorization.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong analytical and problem-solving skills, with an ability to think critically and objectively assess security risks.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Excellent communication skills, with the ability to convey complex security concepts to technical and non-technical stakeholders.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Excitement about collaborating with cross-functional teams to build secure, reliable systems that scale globally.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 3. Principal Software Engineer, Infrastructure Security

- **Posting:** https://jobs.ashbyhq.com/openai/ace42c6d-8663-4b30-9337-ec70cf071d73
- **ID:** `ace42c6d-8663-4b30-9337-ec70cf071d73` · **Source index:** 244 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `REVIEW_ELIGIBILITY` / `US_REMOTE_ADVERTISED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `elevated_title_seniority_review`

**R001 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong software engineering skills with a track record of shipping and operating reliable distributed systems in production.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience building or operating critical infrastructure, especially security infrastructure, at planet scale (e.g., auth services, service-to-service proxies, certificate or key-management systems).

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Deep understanding of security principles, best practices, and common vulnerabilities.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Demonstrated ability to lead cross-team technical initiatives: setting direction, aligning stakeholders, driving execution, and delivering measurable outcomes.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Expertise and curiosity about using frontier models and agents to effectively solve security challenges.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Expertise in securing large-scale cloud platforms (e.g., Azure, AWS, GCP), including multi-cloud networks and cloud-agnostic system design.

Topic signals: `cloud`, `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A proactive mindset, with the ability to identify and address security gaps or inefficiencies through automation and tooling.

Topic signals: `automation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R008 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong analytical and problem-solving skills, with an ability to think critically and objectively assess risks.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Excellent communication skills, with the ability to convey complex security concepts to executive, technical, and non-technical stakeholders.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 4. Principal Security Engineer, Infrastructure Security

- **Posting:** https://jobs.ashbyhq.com/openai/8f1b8c6b-b414-4026-a434-6ca32c3b3e0d
- **ID:** `8f1b8c6b-b414-4026-a434-6ca32c3b3e0d` · **Source index:** 242 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `REVIEW_ELIGIBILITY` / `US_REMOTE_ADVERTISED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `elevated_title_seniority_review`

**R001 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Deep understanding of security principles, best practices, and common vulnerabilities, including strong security judgment under ambiguity

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A proactive mindset, with the ability to identify and address security gaps or inefficiencies through automation and tooling.

Topic signals: `automation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Expertise and curiosity about using frontier models and agents to effectively solve security challenges.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A track record of leading large, cross-org initiatives from concept to rollout, including navigating tradeoffs, driving alignment, and delivering measurable risk reduction.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Deep expertise in the security of cloud platforms (e.g., Amazon AWS, Microsoft Azure), especially securing multi-cloud networks and infrastructure, and designing cloud-agnostic systems.

Topic signals: `cloud`, `dns_network`, `security` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience securing on-prem deployments and datacenters from construction to multi-tenant use.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Familiarity with container security, orchestration security, and authentication/authorization.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong analytical and problem-solving skills, with an ability to think critically and objectively assess security risks.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Excellent communication skills, with the ability to convey complex security concepts to executive, technical, and non-technical stakeholders.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — You will thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Excitement about collaborating with cross-functional teams to build secure, reliable systems that scale globally.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 5. Data Center Compute, OpenHouse Savannah 2026

- **Posting:** https://jobs.ashbyhq.com/openai/6ba0ce24-ad32-4c3b-b49c-b373be9a8480
- **ID:** `6ba0ce24-ad32-4c3b-b49c-b373be9a8480` · **Source index:** 452 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `REVIEW_ELIGIBILITY` / `US_REMOTE_ADVERTISED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 12 lines
- **Review flags:** none assigned

**R001 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have experience building, scaling, or operating complex technical systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — Qualifications** (`EXPECTATION_CONTEXT`)

> Enjoy working on ambiguous, high-impact problems where the path forward is not always defined.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — Qualifications** (`EXPECTATION_CONTEXT`)

> Are comfortable collaborating across disciplines, including software, hardware, operations, and physical infrastructure.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have strong technical judgment and a bias toward execution.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — Qualifications** (`EXPECTATION_CONTEXT`)

> Care deeply about reliability, speed, safety, and operational excellence.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — Qualifications** (`EXPECTATION_CONTEXT`)

> Are excited by the challenge of building infrastructure at unprecedented scale.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — Qualifications** (`EXPECTATION_CONTEXT`)

> Want your work to directly support the development and deployment of frontier AI. Preferred Skills

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have experience with AI infrastructure, high-performance computing, distributed systems, GPU clusters, or cloud-scale platforms.

Topic signals: `cloud`, `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have worked on hardware systems, manufacturing, supply chain, data center development, or large capital infrastructure projects.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have domain expertise in civil, controls, mechanical, hardware, electrical, thermal, power, networking, or facilities engineering.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have helped bring new technical platforms, data centers, factories, or large-scale systems from concept to production.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have experience operating in fast-moving environments where technical depth and execution speed both matter.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 6. Industrial Compute

- **Posting:** https://jobs.ashbyhq.com/openai/6d7ece77-bf25-4f5e-9a84-c5ce26e18c37
- **ID:** `6d7ece77-bf25-4f5e-9a84-c5ce26e18c37` · **Source index:** 418 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `REVIEW_ELIGIBILITY` / `US_REMOTE_ADVERTISED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 12 lines
- **Review flags:** none assigned

**R001 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have experience building, scaling, or operating complex technical systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — Qualifications** (`EXPECTATION_CONTEXT`)

> Enjoy working on ambiguous, high-impact problems where the path forward is not always defined.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — Qualifications** (`EXPECTATION_CONTEXT`)

> Are comfortable collaborating across disciplines, including software, hardware, operations, and physical infrastructure.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have strong technical judgment and a bias toward execution.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — Qualifications** (`EXPECTATION_CONTEXT`)

> Care deeply about reliability, speed, safety, and operational excellence.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — Qualifications** (`EXPECTATION_CONTEXT`)

> Are excited by the challenge of building infrastructure at unprecedented scale.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — Qualifications** (`EXPECTATION_CONTEXT`)

> Want your work to directly support the development and deployment of frontier AI. Preferred Skills

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have experience with AI infrastructure, high-performance computing, distributed systems, GPU clusters, or cloud-scale platforms.

Topic signals: `cloud`, `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have worked on hardware systems, manufacturing, supply chain, data center development, or large capital infrastructure projects.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have domain expertise in civil, controls, mechanical, hardware, electrical, thermal, power, networking, or facilities engineering.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have helped bring new technical platforms, data centers, factories, or large-scale systems from concept to production.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — Qualifications** (`EXPECTATION_CONTEXT`)

> Have experience operating in fast-moving environments where technical depth and execution speed both matter.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 7. Senior Technical Program Manager - Security

- **Posting:** https://jobs.ashbyhq.com/openai/c414f15f-60c4-40b5-a896-d2ad6c7f4415
- **ID:** `c414f15f-60c4-40b5-a896-d2ad6c7f4415` · **Source index:** 15 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `REVIEW_ELIGIBILITY` / `US_REMOTE_ADVERTISED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 6 lines
- **Review flags:** `numeric_experience_not_verified`, `elevated_title_seniority_review`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are an empathetic communicator and leader—able to influence across technical and non-technical audiences, and build durable trust with partners.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have 5+ years of experience leading complex technical programs focused on infrastructure security, data privacy, compliance, or enterprise platform capabilities.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are deeply fluent in the intersection of engineering systems, security controls, and regulatory expectations—and are able to bring clarity and structure across all three.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Thrive in high-trust environments, bring rigor and systems thinking to ambiguity, and operate with a bias for aligned execution over org boundaries.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are structured, detail-oriented, and rigorous in ensuring quality, accountability, and durable delivery.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have a proven record of success driving highly cross-functional efforts across engineering, infrastructure, legal, compliance, and product stakeholders.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 8. Forward Deployed Security Engineer

- **Posting:** https://jobs.ashbyhq.com/openai/89d61ae8-1ce1-4187-9edd-da8029979e41
- **ID:** `89d61ae8-1ce1-4187-9edd-da8029979e41` · **Source index:** 322 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> An active US security clearance.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> 5+ years of security engineering experience, with an emphasis on infrastructure security, application security, network security, datacenter security, and systems engineering.

Topic signals: `dns_network`, `security` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Familiarity with deployment models, including to cloud platforms (Azure, AWS) and the underlying infrastructure primitives (Kubernetes, Terraform)

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Proficiency in programming languages such as Python, Golang, or similar.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A proven track record of developing high-quality, scalable, and secure infrastructure.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience with security operations including insider threat monitoring, network/endpoint detection and response, or red team or penetration testing operations.

Topic signals: `dns_network`, `security`, `testing` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_JIRA`, `PROJECT_DNS`, `CERT_NETWORK`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Comprehensive knowledge of modern adversary tactics, techniques, and procedures.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> The ability to work collaboratively and effectively in a cross-functional team environment.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Thrive in dynamic environments and can navigate ambiguity with ease.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 9. Software Engineer, Manufacturing Infrastructure

- **Posting:** https://jobs.ashbyhq.com/openai/3b08148d-085e-4835-9934-1b7f60e0fdce
- **ID:** `3b08148d-085e-4835-9934-1b7f60e0fdce` · **Source index:** 652 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> 7+ years of hands-on experience, or exceptional accomplishments demonstrating equivalent expertise, in system software, platform software, hardware diagnostics, and cloud infrastructure.

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong programming skills in C, C++, Rust or similar systems languages, with experience building reliable software for real hardware.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Familiarity with scripting in languages such as shell and python as used in automation systems.

Topic signals: `automation`, `python` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Familiarity with Linux-based hardware platforms, OpenBMC, Redfish, firmware update systems, kernel drivers, and fleet management software.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Demonstrated ability to debug live hardware using logs, packet captures, firmware traces, bus captures, lab hosts, BMC journals, Linux tooling, and carefully controlled experiments.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience with hardware bring-up, manufacturing or qualification testing, system diagnostics, release validation, or deployment of high-performance compute, accelerator, server, networking, storage, or embedded platforms.

Topic signals: `dns_network`, `testing` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_JIRA`, `PROJECT_DNS`, `CERT_NETWORK`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Ability to reason across software, firmware, hardware, manufacturing, and operations boundaries, and to turn ambiguous problems into clear requirements, designs, tests, and decisions.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Proven track record working with external vendors, manufacturing partners, or partner engineering teams to define deliverables, review technical work, and drive issues to closure.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Familiarity with platform security topics such as secure boot, firmware signing, device provisioning, attestation, certificate handling, trusted update flows, or access-control design is a plus. To comply with U.S. export control laws and regulations, candidates for this role may need to meet certain legal status requirements as provided in those laws and regulations.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 10. Software Engineer, Resilience Engineering

- **Posting:** https://jobs.ashbyhq.com/openai/1faee5e7-3b2f-4d8c-9a6f-ff0f2a4a42a7
- **ID:** `1faee5e7-3b2f-4d8c-9a6f-ff0f2a4a42a7` · **Source index:** 44 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 17 lines
- **Review flags:** `degree_or_equivalent_not_verified`, `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have a track record of accelerating engineering reliability by building world-class tooling and systems from 0→1.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have a humble attitude, an eagerness to help your colleagues, and a desire to do whatever it takes to make the team succeed.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Own problems end-to-end, and are willing to pick up whatever knowledge you're missing to get the job done.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Enjoy seeking out and addressing bottlenecks and areas for performance improvement in our systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Utilize Infrastructure as Code (IaC) principles to automate infrastructure provisioning and configuration management.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are experienced in collaborating with cross-functional teams to ensure that reliability and scalability are considered in the design and development of new features and services.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Bachelor's degree in Computer Science, Information Technology, or a related field (or equivalent work experience).

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **EDUCATION NOT VERIFIED**

**R008 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Proven experience as an SWE focused on reliability or a similar role in a fast-paced, rapidly scaling company.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Strong proficiency in cloud infrastructure.

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Proficiency in programming languages.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Experience with containerization technologies and container orchestration platforms like Kubernetes.

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Knowledge of IaC tools such as Terraform or CloudFormation.

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Excellent problem-solving and troubleshooting skills.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R014 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Strong communication and collaboration skills.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R015 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Experience with observability tools such as Datadog, Prometheus, Grafana and Splunk.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R016 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Experience with microservices architecture and service mesh technologies.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R017 — Qualifications:** (`EXPECTATION_CONTEXT`)

> Knowledge of security best practices in cloud environments. This role is exclusively based in our San Francisco HQ. We offer relocation assistance to new employees.

Topic signals: `cloud`, `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 11. Software Engineer, Search Infrastructure

- **Posting:** https://jobs.ashbyhq.com/openai/7caed1e8-c6f6-4569-9d45-2d7a7a56a025
- **ID:** `7caed1e8-c6f6-4569-9d45-2d7a7a56a025` · **Source index:** 736 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have significant experience designing, building, and operating large-scale distributed systems, with depth in performance, reliability, or resource efficiency.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring experience in one or more of search, information retrieval, ML infrastructure, inference serving, or other high-throughput online systems.

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong programming and systems debugging skills, and are comfortable working across languages and unfamiliar parts of a production stack.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can turn ambiguous product or research needs into clear technical plans, align partners across teams, and carry projects through deployment and measurable results.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Enjoy learning across systems and ML, investigating unfamiliar problems, and sharing technical decisions and lessons clearly with others.

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 12. System Software Engineer, Consumer Devices

- **Posting:** https://jobs.ashbyhq.com/openai/20f525b7-f958-4c95-a055-f914ab3adb95
- **ID:** `20f525b7-f958-4c95-a055-f914ab3adb95` · **Source index:** 158 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 11 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have shipped production systems software on modern operating systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are proficient in C/C++ and a scripting language, and comfortable with OS internals (concurrency, memory management, filesystems, networking, power management).

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring strong systems debugging skills using debuggers, tracers, profilers, and logs across kernel/user‑space boundaries.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Understand configuration of platform services and interfaces, and can translate requirements into stable, well‑documented APIs.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are fluent in user‑space foundations (service management, IPC, networking, packaging, automation).

Topic signals: `automation`, `dns_network` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `CERT_NETWORK`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience building platform images and designing update mechanisms for reliability and security.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — Preferred Qualifications:** (`PREFERRED_CONTEXT`)

> Exposure to platform security (secure boot, sandboxing, mandatory access controls, attestation).

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — Preferred Qualifications:** (`PREFERRED_CONTEXT`)

> Experience with graphics/media, hardware acceleration, or high‑throughput data paths.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — Preferred Qualifications:** (`PREFERRED_CONTEXT`)

> Familiarity with connectivity stacks and network configuration.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — Preferred Qualifications:** (`PREFERRED_CONTEXT`)

> Observability and diagnostics in distributed or resource‑constrained environments.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — Preferred Qualifications:** (`PREFERRED_CONTEXT`)

> Work on open‑source platforms or contributions to systems projects.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 13. Systems Software Engineer, Management Plane

- **Posting:** https://jobs.ashbyhq.com/openai/21229750-8bd1-4134-a20e-2a8922b88806
- **ID:** `21229750-8bd1-4134-a20e-2a8922b88806` · **Source index:** 298 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> 7+ years of hands-on experience, or exceptional accomplishments demonstrating equivalent expertise, in low-level system software, embedded software, firmware, BMC software, platform software, device drivers, or hardware diagnostics.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Strong programming skills in C, C++, Rust or similar systems languages, with experience building reliable software for real hardware.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Experience with Linux-based hardware platforms, embedded Linux, OpenBMC, Redfish, BMCWeb, IPMI boundaries, BIOS/UEFI, bootloaders, firmware update systems, kernel drivers, RTOS, or fleet management software.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Strong knowledge of hardware/software interfaces such as I2C, SMBus, PMBus, SPI, PCIe, Ethernet, USB, UART, GPIO, JTAG, power controllers, board-level debug tools, or protocol analyzers.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Demonstrated ability to debug live hardware using logs, packet captures, firmware traces, bus captures, lab hosts, BMC journals, Linux tooling, and carefully controlled experiments.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Experience with hardware bring-up, manufacturing or qualification testing, system diagnostics, release validation, or deployment of high-performance compute, accelerator, server, networking, storage, or embedded platforms.

Topic signals: `dns_network`, `testing` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_JIRA`, `PROJECT_DNS`, `CERT_NETWORK`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Ability to reason across software, firmware, hardware, manufacturing, and operations boundaries, and to turn ambiguous problems into clear requirements, designs, tests, and decisions.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Proven track record working with external vendors, manufacturing partners, or partner engineering teams to define deliverables, review technical work, and drive issues to closure.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Familiarity with platform security topics such as secure boot, firmware signing, device provisioning, attestation, certificate handling, trusted update flows, or access-control design is a plus. To comply with U.S. export control laws and regulations, candidates for this role may need to meet certain legal status requirements as provided in those laws and regulations.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 14. Systems Software Engineer, Security, First Party Hardware

- **Posting:** https://jobs.ashbyhq.com/openai/1c48f39f-60ea-4636-87ed-8b4b4f5243e5
- **ID:** `1c48f39f-60ea-4636-87ed-8b4b4f5243e5` · **Source index:** 361 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE:** (`EXPECTATION_CONTEXT`)

> 7+ years of hands-on experience, or exceptional accomplishments demonstrating equivalent expertise, in hardware security, embedded security, firmware security, platform security, or low-level systems security.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE:** (`EXPECTATION_CONTEXT`)

> Experience shipping or securing real hardware platforms, embedded devices, servers, accelerators, networking systems, BMCs, bootloaders, BIOS/UEFI, RTOS, kernels, or firmware update systems.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE:** (`EXPECTATION_CONTEXT`)

> Deep familiarity with secure boot, measured boot, TPMs, hardware roots of trust, device attestation, key provisioning, debug interfaces, firmware signing, recovery, or lifecycle-state design.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE:** (`EXPECTATION_CONTEXT`)

> Strong applied-cryptography judgment for secure boot, attestation, TLS/mTLS, key storage, certificate lifecycle, storage encryption, and long-range transitions such as post-quantum readiness.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE:** (`EXPECTATION_CONTEXT`)

> Ability to read and write systems code in C, C++, or Rust and to use that skill to review, prototype, test, or debug security-critical behavior.

Topic signals: `security`, `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE:** (`EXPECTATION_CONTEXT`)

> Comfort with hardware-software interfaces such as SPI, I2C, SMBus, PCIe, UART, JTAG, SWD, GPIOs, TPMs, and board-level debug tools.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE:** (`EXPECTATION_CONTEXT`)

> Proven track record driving security improvements with hardware, firmware, infrastructure, manufacturing, operations, and partner teams.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE:** (`EXPECTATION_CONTEXT`)

> Experience owning broad, ambiguous security programs end to end, including translating risk into technical requirements, validation plans, and accountable engineering decisions.

Topic signals: `security`, `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE:** (`EXPECTATION_CONTEXT`)

> Clear written and verbal communication, with the ability to turn ambiguous security risks into actionable requirements, design reviews, tests, and decisions. To comply with U.S. export control laws and regulations, candidates for this role may need to meet certain legal status requirements as provided in those laws and regulations.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 15. AI Support Engineer, Government - San Francisco, CA

- **Posting:** https://jobs.ashbyhq.com/openai/48993416-b5f5-4c3f-b7c8-b8ca7c2395e0
- **ID:** `48993416-b5f5-4c3f-b7c8-b8ca7c2395e0` · **Source index:** 535 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `numeric_experience_not_verified`, `degree_or_equivalent_not_verified`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Have 8+ years of experience in User Operations, Engineering, Support Engineering or similar technical roles, ideally within high-growth tech startups or other fast-paced environments.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Are comfortable using emerging technologies (ie. Codex, ChatGPT, OpenAI API, etc.) to script or engineer code (e.g., Python) for automating repetitive tasks and integrating tools.

Topic signals: `api_integration`, `automation`, `python` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Have expert-level SaaS troubleshooting skills with the ability to rapidly understand new technologies and complex concepts.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Polished enterprise communication and are calm with high-stakes customers during live incident calls

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Proven experience building strong relationships with customers and cross-functional partners to drive resolution to complex issues.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Exceptional critical thinker and problem solver with the ability to clearly communicate complex technical issues to both customers and internal teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Thrive in ambiguity, adapt rapidly to change, continuously learn, and proactively seek opportunities for growth.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Bring a humble, team first mindset, a genuine eagerness to help others, and the curiosity to quickly learn whatever knowledge is needed to help both your teammates and our customers succeed.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Bachelor’s degree in Computer Science, Computer Engineering, another relevant technical field, or equivalent practical experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **EDUCATION NOT VERIFIED**

### 16. AI Support Engineer, Government - Washington, D.C.

- **Posting:** https://jobs.ashbyhq.com/openai/6d1d835d-5882-4191-b78e-fd04a4c05f11
- **ID:** `6d1d835d-5882-4191-b78e-fd04a4c05f11` · **Source index:** 538 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `numeric_experience_not_verified`, `degree_or_equivalent_not_verified`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Have 8+ years of experience in User Operations, Engineering, Support Engineering or similar technical roles, ideally within high-growth tech startups or other fast-paced environments.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Are comfortable using emerging technologies (ie. Codex, ChatGPT, OpenAI API, etc.) to script or engineer code (e.g., Python) for automating repetitive tasks and integrating tools.

Topic signals: `api_integration`, `automation`, `python` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Have expert-level SaaS troubleshooting skills with the ability to rapidly understand new technologies and complex concepts.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Polished enterprise communication and are calm with high-stakes customers during live incident calls

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Proven experience building strong relationships with customers and cross-functional partners to drive resolution to complex issues.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Exceptional critical thinker and problem solver with the ability to clearly communicate complex technical issues to both customers and internal teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Thrive in ambiguity, adapt rapidly to change, continuously learn, and proactively seek opportunities for growth.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Bring a humble, team first mindset, a genuine eagerness to help others, and the curiosity to quickly learn whatever knowledge is needed to help both your teammates and our customers succeed.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Bachelor’s degree in Computer Science, Computer Engineering, another relevant technical field, or equivalent practical experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **EDUCATION NOT VERIFIED**

### 17. Connectivity Software Engineer, Consumer Devices

- **Posting:** https://jobs.ashbyhq.com/openai/9b2c68f2-5ce8-44f9-a30c-d8016ac66d86
- **ID:** `9b2c68f2-5ce8-44f9-a30c-d8016ac66d86` · **Source index:** 272 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have deep experience shipping wireless features on Linux-based products

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are highly proficient in C/C++ with scripting experience (Python or shell) and systems debugging (gdb, strace, logs, packet traces)

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Possess deep knowledge of Bluetooth Classic/BLE (HCI, L2CAP, GATT/GAP, profiles) and Wi-Fi (802.11 a/b/g/n/ac/ax, WPA2/3, nl80211, NAN)

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring hands-on experience with BlueZ, wpa_supplicant/hostapd, NetworkManager, and driver bring-up on ARM64 or x86 platforms

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have a proven track record of improving real-world performance and reliability under RF constraints

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Experience with LE Audio (LC3), BLE Mesh, advanced roaming (802.11k/v/r), QoS/WMM, multicast/IGMP

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Coexistence tuning across radios (BT/Wi-Fi/UWB/mmWave) and antenna/RF fundamentals with test equipment workflows

Topic signals: `automation`, `testing` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R008 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Familiarity with UWB (IEEE 802.15.4z, FiRa) ranging/integration; mmWave/Wi-Gig (802.11ad/ay)

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Experience with security and provisioning at scale (EAP-TLS, device identity, secure boot, disk/network hardening)

Topic signals: `dns_network`, `security` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Background in building factory test, interoperability, and certification test plans; upstream/open-source contributions

Topic signals: `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 18. IT Support Specialist

- **Posting:** https://jobs.ashbyhq.com/openai/49ae54dc-3d33-4107-8112-63fac1ee86ca
- **ID:** `49ae54dc-3d33-4107-8112-63fac1ee86ca` · **Source index:** 57 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 8 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong technical expertise in macOS (with a working knowledge of Windows as a plus), identity and device management (e.g., Azure AD, Jamf, Intune), and enterprise collaboration tools like Google Workspace, Office 365, Slack, and Atlassian products.

Topic signals: `cloud`, `intune`, `jamf`, `macos` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Demonstrate excellent written and verbal communication skills, ensuring clarity and professionalism in both internal and external interactions.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Excel at troubleshooting and problem-solving within Mac and macOS environments, ensuring smooth operations for users.

Topic signals: `macos`, `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience orchestrating high-production all-hands events, managing the AV and technical aspects to ensure successful outcomes.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are highly driven and motivated, with a proactive approach to problem solving and continuous improvement.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Exhibit precision and attention to detail in your work, consistently delivering high-quality results.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Possess a customer-first mindset and the ability to clearly articulate technical details to diverse audiences.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are proactive in process improvement and vendor management, with added value in mentoring junior team members, automating workflows via scripting or low-code tools, and managing IT projects as a bonus.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 19. Software Engineer, ML Systems &amp; Training Architecture

- **Posting:** https://jobs.ashbyhq.com/openai/9117987a-7a59-449e-a702-89e8d0e8cb60
- **ID:** `9117987a-7a59-449e-a702-89e8d0e8cb60` · **Source index:** 323 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong software engineering fundamentals and excellent code review judgment.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience with ML systems, training frameworks, GPUs, distributed systems, infrastructure, or similarly complex technical environments.

Topic signals: `distributed_systems`, `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Read and debug unfamiliar codebases quickly, and enjoy getting to root cause.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Ship high-quality code with strong velocity and pragmatic judgment.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are low-ego, responsive, and motivated by helping researchers and engineers move faster.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Prefer being a highly effective hands-on IC over driving broad process-heavy initiatives.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience reviewing messy, fast-moving, or AI-generated codebases. Compensation Range: $295K - $380K USD

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 20. Software Engineer, Ads Manager

- **Posting:** https://jobs.ashbyhq.com/openai/5a4eed17-29d5-41cb-856e-09bfdaffe017
- **ID:** `5a4eed17-29d5-41cb-856e-09bfdaffe017` · **Source index:** 329 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 7+ years of experience building high-scale consumer, enterprise, marketplace, or ads-related systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have a track record of architecting and delivering complex distributed systems, APIs, or advertiser-facing platforms.

Topic signals: `api_integration`, `distributed_systems` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience building in Python / FastAPI and TypeScript / React.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are excited by building both intuitive UI workflows and robust backend systems for external customers.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong product intuition and enjoy translating advertiser needs into clear, reliable, and scalable product experiences.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable navigating ambiguous product spaces and contributing to technical roadmaps and long-term direction.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Thrive in 0→1 environments where systems, architecture, and user experiences must be defined from scratch.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Communicate clearly, think holistically, and make decisions rooted in both user needs and long-term sustainability.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are motivated by building privacy-preserving, safe, and user-first monetization systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bonus: Have experience with ads managers, campaign management systems, advertiser APIs, conversion APIs, pixels, measurement systems, marketplaces, or enterprise ad-tech integrations. Location This role is exclusively based in our Seattle office. We offer relocation assistance to new employees.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 21. Software Engineer, Core Services

- **Posting:** https://jobs.ashbyhq.com/openai/21bfde35-ffec-42d2-a2c6-8a03dad789d5
- **ID:** `21bfde35-ffec-42d2-a2c6-8a03dad789d5` · **Source index:** 90 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 4 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience with distributed systems, caching infrastructure (e.g., Redis, Memcached), metadata storage (e.g., FoundationDB), or workflow orchestration (e.g., Temporal, Cadence).

Topic signals: `automation`, `distributed_systems` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience running containerized services in cloud environments and integrating them into automated build/test/release (CI/CD) workflows.

Topic signals: `automation`, `cloud`, `testing` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Understand trade-offs in consistency models, replication strategies, and performance optimization in multi-region systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Excel at communication and collaboration with cross-functional teams, and are obsessed with delivering customer success.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 22. Software Engineer, Infrastructure - Core Experimentation

- **Posting:** https://jobs.ashbyhq.com/openai/823a05bf-33fb-4d94-9dd8-571723d27b1a
- **ID:** `823a05bf-33fb-4d94-9dd8-571723d27b1a` · **Source index:** 237 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have experience building large-scale distributed systems with strict performance, availability, and correctness requirements.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Enjoy low-latency systems work, including real-time configuration delivery, SDK/runtime performance, caching, concurrency, and high-throughput service design.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have built or operated large-scale data platforms, event pipelines, analytics systems, or query infrastructure where freshness and correctness matter.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Care deeply about reliability, observability, incident response, capacity planning, and the practical craft of keeping critical production systems boring in the best way.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Are excited by the post-acquisition chapter of a high-performing infrastructure team: preserving Statsig's strengths while integrating deeply into OpenAI's product and platform stack.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Want to work on infrastructure that directly affects how ChatGPT, Codex, model measurement, ads, business subscriptions, developer products, and future OpenAI surfaces ship.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Take ownership of complex technical problems end to end and enjoy building infrastructure that lets other teams move faster with more confidence. LOCATION This role is based in Bellevue, WA. The team works in person three days per week and offers relocation assistance to new employees.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 23. Camera Software Engineer, Consumer Devices

- **Posting:** https://jobs.ashbyhq.com/openai/1dc05fc7-ceb7-4827-a905-9d1beb77a4a0
- **ID:** `1dc05fc7-ceb7-4827-a905-9d1beb77a4a0` · **Source index:** 160 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Deep experience shipping embedded camera systems, including sensor bring-up, driver development, and board-level debugging.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Strong C/C++ experience with embedded or Linux-based systems; comfortable debugging across kernel and userspace boundaries.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Hands-on understanding of common camera hardware interfaces (for example, MIPI CSI and sensor control buses) and the practical realities of bring-up, including power, reset, clocking, and sequencing.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Proven track record of building reliable capture paths and effective debug workflows that accelerate iteration through reproducible failures and well-scoped fixes.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Experience with common mobile or embedded SoC camera stacks and vendor frameworks.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Experience integrating and debugging hardware acceleration blocks adjacent to camera pipelines, such as video encode and decode paths.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Familiarity building higher-level capture pipelines (for example, GStreamer) on top of low-level camera enablement.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 24. Forward Deployed Software Engineer - NYC

- **Posting:** https://jobs.ashbyhq.com/openai/533c0fc9-b773-476d-9f96-a0528efbab0e
- **ID:** `533c0fc9-b773-476d-9f96-a0528efbab0e` · **Source index:** 141 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 25. Forward Deployed Software Engineer - Seattle

- **Posting:** https://jobs.ashbyhq.com/openai/7b90b83c-ec28-4e65-a235-6675e37b91c3
- **ID:** `7b90b83c-ec28-4e65-a235-6675e37b91c3` · **Source index:** 226 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 26. Forward Deployed Software Engineer - SF

- **Posting:** https://jobs.ashbyhq.com/openai/00207abc-49b7-465c-a219-f7c1140f8047
- **ID:** `00207abc-49b7-465c-a219-f7c1140f8047` · **Source index:** 43 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 27. Full Stack Software Engineer, Cybersecurity Products

- **Posting:** https://jobs.ashbyhq.com/openai/88654e7f-4e23-4e75-8e54-18c10d09b093
- **ID:** `88654e7f-4e23-4e75-8e54-18c10d09b093` · **Source index:** 347 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 4 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience shipping production full-stack products across modern web frontends and backend services.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can design clear APIs and data models, reason about asynchronous systems, and diagnose reliability or performance problems.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Care about building products that experts trust while making sophisticated workflows usable for a broader set of engineers.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring strong judgment around privacy, security, and correctness. Application-security or cybersecurity experience is helpful, but not required.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 28. Security Engineer, Application Security

- **Posting:** https://jobs.ashbyhq.com/openai/0322d6d8-6588-4209-a304-83e768063a25
- **ID:** `0322d6d8-6588-4209-a304-83e768063a25` · **Source index:** 18 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Extensive experience in information security, cybersecurity, or a related field, with a significant portion of that experience in leadership or management roles.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Deep understanding of security technologies, tools, and best practices, including experience with secure coding practices, threat modeling, risk assessments, and incident response.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Experience in application security, software development, or related areas with a strong understanding of secure coding practices and application security frameworks.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Proficiency in programming languages (such as Python, Java, C++, etc.), knowledge of security tools (e.g., Burp Suite, OWASP ZAP), and familiarity with security protocols and encryption methods.

Topic signals: `python`, `security` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Strong written and verbal communication skills, with the ability to explain complex security issues to both technical and non-technical audiences

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 29. Security Engineer, Application Security

- **Posting:** https://jobs.ashbyhq.com/openai/1e110226-448a-4c0b-b0e4-d0f5df579fbf
- **ID:** `1e110226-448a-4c0b-b0e4-d0f5df579fbf` · **Source index:** 56 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Extensive experience in information security, cybersecurity, or a related field, with a significant portion of that experience in leadership or management roles.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Deep understanding of security technologies, tools, and best practices, including experience with secure coding practices, threat modeling, risk assessments, and incident response.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Experience in application security, software development, or related areas with a strong understanding of secure coding practices and application security frameworks.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Proficiency in programming languages (such as Python, Java, C++, etc.), knowledge of security tools (e.g., Burp Suite, OWASP ZAP), and familiarity with security protocols and encryption methods.

Topic signals: `python`, `security` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Strong written and verbal communication skills, with the ability to explain complex security issues to both technical and non-technical audiences

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 30. Security Engineer, Application Security

- **Posting:** https://jobs.ashbyhq.com/openai/ec5a5d98-6314-44d9-9466-8d4d7ee866f6
- **ID:** `ec5a5d98-6314-44d9-9466-8d4d7ee866f6` · **Source index:** 58 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Extensive experience in information security, cybersecurity, or a related field, with a significant portion of that experience in leadership or management roles.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Deep understanding of security technologies, tools, and best practices, including experience with secure coding practices, threat modeling, risk assessments, and incident response.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Experience in application security, software development, or related areas with a strong understanding of secure coding practices and application security frameworks.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Proficiency in programming languages (such as Python, Java, C++, etc.), knowledge of security tools (e.g., Burp Suite, OWASP ZAP), and familiarity with security protocols and encryption methods.

Topic signals: `python`, `security` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Strong written and verbal communication skills, with the ability to explain complex security issues to both technical and non-technical audiences

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 31. Software Engineer, Ads Integrity

- **Posting:** https://jobs.ashbyhq.com/openai/596e543a-0ab9-471e-a1ff-40fd55c74fce
- **ID:** `596e543a-0ab9-471e-a1ff-40fd55c74fce` · **Source index:** 432 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 12 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have significant experience building and operating large-scale backend or distributed systems.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have worked on integrity, trust and safety, anti-abuse, fraud, risk, security, business verification, or another domain where systems must operate against sophisticated or evolving adversaries.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have built detection, decisioning, enforcement, verification, investigation, or risk infrastructure in production.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Understand how rules, heuristics, risk signals, ML-based signals, and human review can work together within a dependable production system.

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable building ML-adjacent infrastructure and partnering closely with ML teams without needing to be an ML domain expert.

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have built low-latency, high-throughput services or data pipelines with demanding reliability, correctness, privacy, and security requirements.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can reason about false positives, adversarial behavior, explainability, auditability, and the operational impact of automated enforcement.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Think holistically about threat models, system architecture, data quality, observability, user impact, and ecosystem health.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can define technical direction in an ambiguous 0→1 environment and independently drive complex work across teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Communicate clearly and work effectively across engineering, product, policy, safety, security, operations, and machine-learning teams.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience with ads, ads integrity, advertiser systems, or ads fraud. This is a plus, but not a requirement.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are excited to build the integrity foundation for a new product area rather than inherit a mature system.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 32. Software Engineer, Agent Infrastructure

- **Posting:** https://jobs.ashbyhq.com/openai/c1316397-25bb-4add-9e9d-0e3ea8ba929a
- **ID:** `c1316397-25bb-4add-9e9d-0e3ea8ba929a` · **Source index:** 25 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 6 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have deep experience working on large-scale machine learning infrastructure. You know how to reason about training at scale, identifying bottlenecks and engineering solutions to optimize system performance in training environments.

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Know how to build new things from 0-1 quickly, and then scale them 1,000,000x.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have a keen eye for performance and optimization. You know how to squeeze the most performance out of complex, globally-distributed systems.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Know your way around cloud platforms and work with infrastructure-as-code tech like Terraform.

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are driven by solving complex, ambiguous problems at the intersection of infrastructure scalability, virtualization efficiency, and agentic capabilities.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have deep technical expertise in virtualization and containerization technologies (e.g. Kata, Firecracker, gVisor, Sysbox) and are passionate about optimizing runtime performance.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 33. Software Engineer, Cloud Infrastructure

- **Posting:** https://jobs.ashbyhq.com/openai/12342ebb-dcd4-45e2-b875-fc5447fdb7d8
- **ID:** `12342ebb-dcd4-45e2-b875-fc5447fdb7d8` · **Source index:** 94 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 5+ years building core infrastructure

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience operating orchestration systems such as Kubernetes at scale

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience building abstractions over cloud platforms

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Take pride in building and operating scalable, reliable, secure systems

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable with ambiguity and rapid change This role is exclusively based in our San Francisco HQ. We offer relocation assistance to new employees.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 34. Software Engineer, Data Infrastructure

- **Posting:** https://jobs.ashbyhq.com/openai/f763c6b3-5167-4a67-b691-4c3fa2c44156
- **ID:** `f763c6b3-5167-4a67-b691-4c3fa2c44156` · **Source index:** 6 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 4+ years in data infrastructure engineering OR

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 4+ years in infrastructure engineering with a strong interest in data

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Take pride in building and operating scalable, reliable, secure systems

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable with ambiguity and rapid change

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have an intrinsic desire to learn and fill in missing skills, and an equally strong talent for sharing learnings clearly and concisely with others This role is exclusively based in our San Francisco HQ. We offer relocation assistance to new employees.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 35. Software Engineer, Developer Productivity

- **Posting:** https://jobs.ashbyhq.com/openai/2cba0d45-7a4f-4f38-ac73-3f8633bf0349
- **ID:** `2cba0d45-7a4f-4f38-ac73-3f8633bf0349` · **Source index:** 8 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 4 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 5+ years of experience in engineering, including 3+ years of experience in infrastructure building tooling for developers.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience-driven empathy for the tools, frustrations, and processes that slow engineering teams down and lead to toil or burnout.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have a voracious and intrinsic desire to learn and fill in missing skills—and an equally strong talent for sharing learnings clearly and concisely with others.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable with ambiguity and rapidly changing conditions. You view changes as an opportunity to add structure and order when necessary. As technical context: at the heart of our infrastructure is a large-scale deployment of GPU nodes running in dozens of Kubernetes clusters across regions. Some core technologies we build with include Terraform, Buildkite, Postgres, Cosmos DB, Kafka, Python, and FastAPI. This role is exclusively based in our San Francisco HQ. We offer relocation assistance to new employee.

Topic signals: `cloud`, `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 36. Software Engineer, Fleet Management

- **Posting:** https://jobs.ashbyhq.com/openai/7809102e-e82a-4678-bf7c-221de8acc0d6
- **ID:** `7809102e-e82a-4678-bf7c-221de8acc0d6` · **Source index:** 22 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 6 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong software engineering skills with experience in large-scale infrastructure environments.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Possess broad knowledge of cluster-level systems (e.g., Kubernetes, CI/CD pipelines, Terraform, cloud providers).

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have deep expertise in server-level systems (e.g., systems, containerization, Chef, Linux kernels, firmware management, host routing).

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are passionate about optimizing the performance and reliability of large compute fleets.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Thrive in dynamic environments and are eager to solve complex infrastructure challenges.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Value automation, efficiency, and continuous improvement in everything you build.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 37. Software Engineer, Monetization Delivery

- **Posting:** https://jobs.ashbyhq.com/openai/a4ea79c8-e79f-4126-8c1f-032289024961
- **ID:** `a4ea79c8-e79f-4126-8c1f-032289024961` · **Source index:** 151 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 10+ years of experience building and operating large-scale distributed systems

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience designing mission-critical systems with demanding reliability, performance, and correctness requirements

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Think in systems—architecture, data flows, operational concerns, observability, and long-term maintainability

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable defining technical direction in ambiguous 0→1 environments

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Enjoy working cross-functionally to shape product requirements and system capabilities

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Communicate clearly, reason holistically, and make decisions grounded in user needs and long-term system health

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bonus: Experience in ads systems, marketplaces, AI/ML infra, or other monetization-intensive domains

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 38. Software Engineer, Monetization Product &amp; Platform

- **Posting:** https://jobs.ashbyhq.com/openai/c51e48ce-31ad-4176-a6d5-4a785b44ab73
- **ID:** `c51e48ce-31ad-4176-a6d5-4a785b44ab73` · **Source index:** 169 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 8 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have 7+ years of experience building high-scale consumer, enterprise, or ads-related systems

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have a track record of architecting and delivering complex distributed systems with high reliability and performance requirements

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are comfortable navigating ambiguous product spaces and contributing to technical roadmaps and long-term direction

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Bring strong product intuition and enjoy collaborating deeply with Product, Design, and Research

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Thrive in 0→1 environments where systems, architecture, and user experiences must be defined from scratch

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Communicate clearly, think holistically, and make decisions rooted in both user needs and long-term sustainability

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are motivated by building privacy-preserving, safe, and user-first monetization systems

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Bonus: Have experience in ads systems, marketplaces, or other monetization-heavy domains LOCATION This role is exclusively based in our San Francisco HQ. We offer relocation assistance to new employees.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 39. Software Engineer, Plugin Developer Platform

- **Posting:** https://jobs.ashbyhq.com/openai/71838fdf-4476-490c-81b6-4bf0746f6774
- **ID:** `71838fdf-4476-490c-81b6-4bf0746f6774` · **Source index:** 558 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 40. Software Engineer, Plugin Ecosystem

- **Posting:** https://jobs.ashbyhq.com/openai/e42305bf-2266-4dff-82ad-42be7ddac495
- **ID:** `e42305bf-2266-4dff-82ad-42be7ddac495` · **Source index:** 703 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 41. Software Engineer, Privacy Engineering

- **Posting:** https://jobs.ashbyhq.com/openai/07153f7c-7e8b-4283-a879-cb07a224e083
- **ID:** `07153f7c-7e8b-4283-a879-cb07a224e083` · **Source index:** 61 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have substantial experience designing and operating large-scale data platforms, privacy infrastructure, or governance systems in complex production environments.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have led architecture and multi-team execution for one or more data-governance domains, such as metadata and lineage, retention and deletion, access governance, or data-use controls.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can translate ambiguous policy, legal, security, and product requirements into clear system boundaries, technical standards, phased roadmaps, and measurable outcomes.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Influence senior stakeholders and engineering teams without relying on formal authority, communicate tradeoffs clearly, and build durable cross-functional alignment.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Take end-to-end ownership of high-trust systems, including correctness, scalability, auditability, operational resilience, and the developer and operator experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 42. Software Engineer, Private Computing

- **Posting:** https://jobs.ashbyhq.com/openai/0f887fe6-39f4-44f6-8ee5-230c3002f0d7
- **ID:** `0f887fe6-39f4-44f6-8ee5-230c3002f0d7` · **Source index:** 370 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Care deeply about user privacy and security

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 5+ years of experience in professional software engineering

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience building and scaling confidential computing or encryption technologies in production environments

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience with Kubernetes and cloud orchestration systems

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Take pride in building and operating scalable, reliable, secure systems

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can collaborate well and drive alignment in the face of difficult trade-offs

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable with ambiguity and rapid change Workplace &amp; Location This role is based in San Francisco, CA. We follow a hybrid model with 4 days a week in the office and offer relocation assistance to new employees.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 43. Systems Integration Engineer, Build Systems \| Consumer Devices

- **Posting:** https://jobs.ashbyhq.com/openai/9104a37c-6ae0-499b-a2f7-2785e63b5f0c
- **ID:** `9104a37c-6ae0-499b-a2f7-2785e63b5f0c` · **Source index:** 484 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 8 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — Minimum Qualifications:** (`STATED_REQUIREMENT_CONTEXT`)

> 5+ years of engineering experience, including significant experience building infrastructure and tooling for developers

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — Minimum Qualifications:** (`STATED_REQUIREMENT_CONTEXT`)

> Hands-on experience with Bazel, Buck, Gradle, or similar build systems, and understand the trade offs of hermetic builds, dependency graphs, caching, sandboxing, and remote execution

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — Minimum Qualifications:** (`STATED_REQUIREMENT_CONTEXT`)

> Have built CI systems at scale, especially in environments where build time, queue time, test flakiness, and developer trust materially affect engineering velocity You May Be A Strong Fit If You

Topic signals: `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — Minimum Qualifications:** (`STATED_REQUIREMENT_CONTEXT`)

> Are comfortable with owning production software and working in environments with strong SLA requirements

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — Minimum Qualifications:** (`STATED_REQUIREMENT_CONTEXT`)

> Can debug distributed build and CI failures across source control, dependency management, containers, runners, remote caches, test frameworks, and service infrastructure.

Topic signals: `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — Minimum Qualifications:** (`STATED_REQUIREMENT_CONTEXT`)

> Care deeply about developer experience and have empty for the small sources of friction that slow teams down or create operational toil

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — Minimum Qualifications:** (`STATED_REQUIREMENT_CONTEXT`)

> Are excited to apply AI to developer infrastructure in ways that increase team velocity without weakening quality, reliability, or safety

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — Minimum Qualifications:** (`STATED_REQUIREMENT_CONTEXT`)

> Have operated in a polyrepo environment with source code from multiple parties

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 44. Android Systems Engineer, Consumer Devices

- **Posting:** https://jobs.ashbyhq.com/openai/b08126cc-8134-45f0-aeb3-4b00e96547de
- **ID:** `b08126cc-8134-45f0-aeb3-4b00e96547de` · **Source index:** 487 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 13 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have deep experience building and shipping high-quality Android software used by real customers.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have strong knowledge of the Android platform beyond UI and application development, including framework APIs, system services, process and application lifecycle, permissions, IPC, background execution, and device capabilities.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are highly proficient in Kotlin and/or Java and comfortable working across a large Android codebase.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have experience working with AOSP, Android framework internals, system applications, privileged APIs, device software, or OEM-specific Android integrations.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have experience integrating software with hardware or device capabilities and enjoy debugging problems that cross application, operating-system, and device boundaries.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Understand the realities of building across the Android ecosystem, including OS versions, device configurations, OEM customizations, permissions, power management, and platform fragmentation.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Care deeply about product quality and user experience, not just technical correctness.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Think creatively about what new platform capabilities make possible and enjoy turning emerging technology into intuitive consumer experiences.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Thrive in ambiguous, rapidly changing environments where the right technical and product approach is not obvious at the outset.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Take ownership of problems, develop strong points of view, and can independently drive work from exploration through production.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Enjoy 0→1 product development and are energized by building experiences for which established patterns may not yet exist.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Stay current with new Android technologies, APIs, operating-system capabilities, and broader developments across the mobile ecosystem.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R013 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Collaborate effectively with internal teams and external platform or device partners.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 45. Data Engineer

- **Posting:** https://jobs.ashbyhq.com/openai/fc5bbc77-a30c-4e7a-9acc-8a2e748545b4
- **ID:** `fc5bbc77-a30c-4e7a-9acc-8a2e748545b4` · **Source index:** 10 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 3+ years of experience as a data engineer and 8+ years of any software engineering experience(including data engineering).

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Proficiency in at least one programming language commonly used within Data Engineering, such as Python, Scala, or Java.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Experience with distributed processing technologies and frameworks, such as Hadoop, Flink and distributed storage systems (e.g., HDFS, S3).

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Expertise with any of ETL schedulers such as Airflow, Dagster, Prefect or similar frameworks.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Solid understanding of Spark and ability to write, debug and optimize Spark code. This role is exclusively based in our San Francisco HQ. Some of our roles are also located in our Mountain View or New York offices. We offer relocation assistance to new employees.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 46. Full Stack Software Engineer, Sales Platform

- **Posting:** https://jobs.ashbyhq.com/openai/1f7c6071-ad3a-4903-9b05-4684f5c1a7c8
- **ID:** `1f7c6071-ad3a-4903-9b05-4684f5c1a7c8` · **Source index:** 793 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 4 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> 5+ years of professional software engineering experience, excluding internships, on product-driven teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Experience building large-scale, full-stack software applications in collaboration with cross-functional teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Make sound architecture and product decisions for connected systems, with attention to sensitive data, reliability, and maintainability.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Communicate clearly and collaborate across engineering and business teams. The EPT platform uses Python/FastAPI and React, but experience with those specific technologies is not required. Agentic-system experience is a plus, not a requirement.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 47. Personnel Security Specialist

- **Posting:** https://jobs.ashbyhq.com/openai/2ee660bf-1911-4619-9282-751cd9fc5c61
- **ID:** `2ee660bf-1911-4619-9282-751cd9fc5c61` · **Source index:** 206 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have hands-on personnel security experience supporting a cleared defense contractor, Intelligence Community organization, federal customer, or comparable classified environment.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have directly managed clearance verification, access processing, indoctrinations, debriefings, visit requests, security briefings, and onboarding or offboarding for cleared personnel.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have working experience with DISS and NBIS/eApp; familiarity with NISS, SWFT, Scattered Castles, or customer-specific security systems is a plus.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Understand the NISPOM, applicable Security Executive Agent Directives, and government or customer personnel security requirements.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are highly organized and can manage competing priorities, sensitive records, recurring deadlines, and a high-volume case queue without losing accuracy.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Communicate clearly and respectfully, particularly when explaining complex requirements or supporting employees through sensitive and sometimes frustrating processes.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Demonstrate discretion with personal information and sound judgment about when to involve security leadership, Legal, People, or government security officials.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Look for practical ways to improve operational reliability through documentation, metrics, templates, and approved AI tools, agents, and automations, while protecting sensitive information and preserving required human review and security judgment.

Topic signals: `automation`, `documentation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have experience supporting SCI or SAP access, customer-specific nominations, visit authorization requests, or related access packages.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Hold active Top Secret eligibility and current SCI access, and can obtain and maintain any customer-required polygraph or additional access approvals.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 48. Software Engineer, Ad Formats

- **Posting:** https://jobs.ashbyhq.com/openai/0b212a4a-6709-4da8-b59d-283a9bbf812e
- **ID:** `0b212a4a-6709-4da8-b59d-283a9bbf812e` · **Source index:** 327 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 7+ years of experience building high-scale consumer product experiences, creative systems, ads systems, or platform infrastructure.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have a track record of architecting and delivering complex systems that power user-facing experiences across multiple surfaces.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Care deeply about product quality, performance, reliability, and the details of how experiences render for users.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable working at the intersection of frontend systems, backend infrastructure, design, and product strategy.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring strong product intuition and enjoy collaborating deeply with Product, Design, and Research.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Thrive in 0→1 environments where systems, architecture, and user experiences must be defined from scratch.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Communicate clearly, think holistically, and make decisions rooted in both user needs and long-term sustainability.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are motivated by building privacy-preserving, safe, and user-first monetization systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bonus: Have experience with ads formats, creative rendering systems, content delivery, design systems, media platforms, or interactive product experiences. Location This role is exclusively based in our San Francisco HQ. We offer relocation assistance to new employees.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 49. Software Engineer, Collective Communication

- **Posting:** https://jobs.ashbyhq.com/openai/340c0c22-8d8f-4232-b17e-f642b64c25c3
- **ID:** `340c0c22-8d8f-4232-b17e-f642b64c25c3` · **Source index:** 14 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 3 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have written distributed algorithms using RDMA in the past.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable writing low level performance sensitive CPU and/or GPU code.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are familiar with network simulation techniques.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 50. Software Engineer, Distributed Data Systems - Robotics

- **Posting:** https://jobs.ashbyhq.com/openai/da07ba71-81fd-47c7-adb1-2b2d1eaed325
- **ID:** `da07ba71-81fd-47c7-adb1-2b2d1eaed325` · **Source index:** 143 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 4 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong experience with distributed systems and large-scale infrastructure with a strong interest in data.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are detail-oriented and bring rigor to building and maintaining reliable systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Demonstrate excellent software engineering fundamentals and organizational skills.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable with ambiguity and rapid change

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 51. Software Engineer, Research - Human Data

- **Posting:** https://jobs.ashbyhq.com/openai/4d6a5951-9838-434c-830a-22cb938ea228
- **ID:** `4d6a5951-9838-434c-830a-22cb938ea228` · **Source index:** 79 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have strong software engineering fundamentals and experience building production systems at scale

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Enjoy full-stack development with end-to-end ownership — from backend pipelines to user interfaces

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are motivated by high-impact collaboration with research teams and solving novel, ambiguous problems

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are excited to shape how AI systems learn from human preferences and reflect a broad range of human values

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Care deeply about inclusive tooling and building systems that enhance model safety, reliability, and usefulness

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 52. Software Engineer, Research Developer Productivity

- **Posting:** https://jobs.ashbyhq.com/openai/e6d5ca02-f30b-4ac5-a69d-c947efb430f9
- **ID:** `e6d5ca02-f30b-4ac5-a69d-c947efb430f9` · **Source index:** 111 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 4 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have supported large monorepo development and deployment before

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are a proficient Python programmer working in large monorepos

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are proficient with Docker and Kubernetes

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Experienced in CI/CD

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 53. Software Engineer, Shop/Feed Ads

- **Posting:** https://jobs.ashbyhq.com/openai/4d7145cf-ef4e-4a39-b1ef-b58e4e5c06d2
- **ID:** `4d7145cf-ef4e-4a39-b1ef-b58e4e5c06d2` · **Source index:** 791 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have extensive experience building and operating large-scale distributed systems, with direct ownership of product ads retrieval, ranking infrastructure, or delivery.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Understand merchant feeds and shopping systems, including how catalog quality, product availability, and freshness affect relevance and ads performance.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have built systems for shopping or product ads at platforms such as Google Shopping, YouTube, Amazon, or a comparable environment.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Alternatively, have operated at Senior Staff-level scope or above, leading the architecture and delivery of large-scale catalogs, search and indexing platforms, ads serving, or related backend systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have built low-latency, high-throughput services and data pipelines with demanding reliability and correctness requirements.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Can reason across ingestion, storage, indexing, retrieval, ranking, and serving, and make thoughtful tradeoffs between freshness, relevance, latency, and cost.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Are comfortable partnering with machine-learning teams to bring ranking models and signals into dependable production systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Can define technical direction in an ambiguous 0→1 environment and independently drive complex work across teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Communicate clearly and make technical decisions grounded in user value, merchant experience, and long-term system health.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 54. Forward Deployed Software Engineer, Gov

- **Posting:** https://jobs.ashbyhq.com/openai/db5a708d-1d7a-4aa3-8dd3-0d0423b6b69f
- **ID:** `db5a708d-1d7a-4aa3-8dd3-0d0423b6b69f` · **Source index:** 107 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Bring 5+ years of engineering or technical deployment experience, ideally in customer-facing or government environments.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R002 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Active TS/SCI clearance or equivalent

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Have scoped and delivered complex systems in fast-moving or ambiguous contexts.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Write and review production-grade code across frontend and backend, using Python, JavaScript, or similar stacks.

Topic signals: `javascript`, `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Are familiar with cloud deployment models (Azure, AWS), Kubernetes, Terraform, and related infrastructure.

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Have experience building or deploying systems powered by LLMs or generative models, and understand how model behavior affects product experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Simplify complexity, make fast, sound decisions under pressure, and communicate clearly across technical and non-technical audiences.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Spot risks early, adjust without slowing down, and model calm judgment when stakes are high.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Are humble, collaborative, and eager to help others with empathy.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — You might thrive in this role if you** (`EXPECTATION_CONTEXT`)

> Operate with high horsepower, thrive in dynamic environments, and can ruthlessly prioritize across multiple projects.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 55. Full Stack Software Engineer, Product Explorations

- **Posting:** https://jobs.ashbyhq.com/openai/4d1ede8c-3d4c-4503-8408-81e4b68c5c91
- **ID:** `4d1ede8c-3d4c-4503-8408-81e4b68c5c91` · **Source index:** 625 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `degree_or_equivalent_not_verified`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience building and shipping full stack product experiences, from early prototypes through production

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Thrive in early-stage, highly iterative environments and can move quickly from idea to execution with limited structure

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring strong product intuition and an ability to identify what matters most for users and the business

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Communicate clearly and collaborate effectively across engineering, product, design, and research

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring a high degree of autonomy, agency, and ownership in ambiguous environments

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **EDUCATION NOT VERIFIED**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Want to work at the intersection of model capabilities, product development, and user impact Location:

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> This role is exclusively based in our San Francisco HQ. We offer relocation assistance to new employees.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 56. Software Engineer, Fleet Infrastructure

- **Posting:** https://jobs.ashbyhq.com/openai/a58add97-1968-4d5c-b504-ab62bea12df3
- **ID:** `a58add97-1968-4d5c-b504-ab62bea12df3` · **Source index:** 23 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 6 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience with hyperscale compute systems

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Possess strong programming skills

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience working in public clouds (especially Azure)

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience working in Kubernetes

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Execution focused mentality paired with a rigorous focus on user requirements

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> As a bonus, have an understanding of AI/ML workloads

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 57. Senior Support Engineer - San Francisco

- **Posting:** https://jobs.ashbyhq.com/openai/5431666c-530b-49c0-b67e-32477f9eaf5e
- **ID:** `5431666c-530b-49c0-b67e-32477f9eaf5e` · **Source index:** 48 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `numeric_experience_not_verified`, `degree_or_equivalent_not_verified`, `elevated_title_seniority_review`, `relocation_terms_and_amount_not_confirmed`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have a Bachelor’s degree in Computer Science or a related field. A strong software engineering foundation is important for this role’s success.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **EDUCATION NOT VERIFIED**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 8+ years of experience in technical operations roles such as SRE/NOC, designing monitoring systems and resolving production issues in fast-paced and mission-critical environments. A strong track record of troubleshooting complex technical problems at the systems level.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF** · **YEARS NOT VERIFIED**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have deep familiarity with modern monitoring, alerting, and observability practices. Hands‑on experience setting up or managing metrics, logging, and tracing for distributed systems (e.g., understanding of SLIs/SLOs, alert tuning, dashboard creation).

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have proven experience leading incident response for high‑severity outages or service disruptions. Able to perform real‑time incident coordination, root cause analysis, and drive follow‑ups (post‑mortems, action items) to prevent recurrence. Knowledge of industry best practices for incident management and fault diagnosis.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong skills in scripting or software engineering (e.g., Python or similar) to automate repetitive tasks and integrate tools.

Topic signals: `automation`, `python` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have solid understanding of cloud infrastructure and distributed systems fundamentals. Comfortable working with cloud services, load balancers, databases, and containerized applications.

Topic signals: `cloud`, `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are effective at working cross‑functionally in a high‑trust environment. Strong communication skills to explain technical issues and resolutions to both engineering and non‑technical stakeholders. You can coordinate efforts across teams and are comfortable providing updates in the midst of an ongoing incident. #LI-NM2

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 58. Senior Software Engineer - Research Platform, Consumer Devices

- **Posting:** https://jobs.ashbyhq.com/openai/6d9925f4-3d0a-4710-8304-032d0080d12d
- **ID:** `6d9925f4-3d0a-4710-8304-032d0080d12d` · **Source index:** 321 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 11 lines
- **Review flags:** `elevated_title_seniority_review`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have 7+ years of professional software engineering experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have strong full-stack experience across web applications, backend services, APIs, and data models, including ownership of complex systems spanning multiple services or repositories.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have expertise in generative AI, multimodal models, or model-evaluation systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have built effective internal tools for both technical and non-technical users.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are comfortable debugging distributed workflows and production infrastructure.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have strong product judgment and can translate ambiguous requirements into concrete plans.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are energized by working between designers and researchers in a multidisciplinary team, connecting qualitative judgment to rigorous evidence.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Communicate clearly and work effectively across engineering, design, and research.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — Nice to have:** (`PREFERRED_CONTEXT`)

> Expertise in synthetic data generation, simulation, conversational AI, speech, video, motion, or embodied interaction.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience with automated graders, human evaluation, supervised fine-tuning, reinforcement learning, or experiment- and dataset-management platforms.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — Nice to have:** (`PREFERRED_CONTEXT`)

> Operated GPU-backed inference or rollout workloads at very large scale.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 59. Senior Staff Software Engineer, Identity Infrastructure Engineering

- **Posting:** https://jobs.ashbyhq.com/openai/72a58872-70e2-4340-a259-e9bea3596883
- **ID:** `72a58872-70e2-4340-a259-e9bea3596883` · **Source index:** 311 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `elevated_title_seniority_review`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> 10+ years building and operating large-scale infrastructure, platform, or backend systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Deep experience with cloud infrastructure, identity systems, distributed systems, and infrastructure-as-code.

Topic signals: `cloud`, `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience leading complex technical initiatives across teams and driving architecture in ambiguous environments.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience building security-critical systems involving authentication, authorization, access governance, privileged access, or policy enforcement.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong software engineering fundamentals with experience in Go, Rust, Python, or similar languages.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Ability to debug across code, cloud infrastructure, identity systems, networking, and operations.

Topic signals: `cloud`, `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> High bar for reliability, security, auditability, and operational rigor in mission-critical systems. This role is based in San Francisco, CA. We use a hybrid work model of three days in the office per week and offer relocation assistance to new employees.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 60. Network Engineer

- **Posting:** https://jobs.ashbyhq.com/openai/9f78c41f-8d39-46c9-b9c3-c3b075905b24
- **ID:** `9f78c41f-8d39-46c9-b9c3-c3b075905b24` · **Source index:** 533 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience shaping a multi-quarter network roadmap while supporting production operations and changing delivery needs.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience with optical transport and carrier services, including DWDM, wavelengths, dark fiber, DIA, or similar technologies.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience with cloud and virtual WAN architectures such as Azure Virtual WAN, AWS Transit Gateway, or comparable services.

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience with campus, data center, colocation, or PoP architecture, interconnects, high-availability design, and operational handoff.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience building internal platforms, self-service workflows, or AI-assisted automation that measurably reduces operational toil. This role is based in San Francisco, CA. We use a hybrid work model of 3 days in the office per week and offer relocation assistance to new employees.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 61. Applied AI Engineer, Plugins

- **Posting:** https://jobs.ashbyhq.com/openai/ca9e0aeb-6df1-4b73-8ec0-2e9e124712f1
- **ID:** `ca9e0aeb-6df1-4b73-8ec0-2e9e124712f1` · **Source index:** 427 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 13 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 4-6 years of professional software engineering experience and are strong enough technically to contribute to the platform itself while still enjoying hands-on coding.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have built and operated production APIs, backend services, developer platforms, apps, plugins, connectors, or integrations and can reason across frontend, backend, auth, reliability, privacy, evaluations, and UX constraints.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring strong product sense and can distinguish a plugin that “works” from one that will be genuinely useful to users.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Communicate clearly with external engineers, product leaders, executives, and internal cross-functional stakeholders.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can make ambiguous partner ideas concrete through runnable prototypes, API contracts, technical specs, and pragmatic implementation guidance.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable reading unfamiliar code, making targeted platform changes, and debugging distributed systems with logs, traces, metrics, and experiments.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Care deeply about user trust, privacy, data handling, and product quality in AI-powered experiences.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Balance urgency with judgment and can keep launches moving while staying precise about details that matter.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Experience with OAuth/login flows, API design, webhooks, schemas, rate limits, observability, SDKs, and production launch operations.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Prior customer-facing or partner-facing engineering experience, including leading technical calls, navigating ambiguity, and helping external teams ship production software.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Familiarity with AI products, LLM APIs, tool calling, MCP, ChatGPT or Codex surfaces, developer platforms, or marketplace ecosystems.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R012 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Comfortable making targeted changes across backend services, frontend surfaces, SDKs, docs, internal tools, or monorepo codebases when needed.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — Preferred qualifications:** (`PREFERRED_CONTEXT`)

> Strong written communication skills, including docs, implementation notes, launch plans, and partner-facing technical guidance.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 62. Networking Operating System Firmware Engineer

- **Posting:** https://jobs.ashbyhq.com/openai/f6b9903c-9034-436b-a4ec-4c8643a6d0dd
- **ID:** `f6b9903c-9034-436b-a4ec-4c8643a6d0dd` · **Source index:** 293 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Proven experience working with SONiC or comparable NOS stacks such as FBOSS, Cumulus Linux, Arista EOS, Junos PFE-level integration, or equivalent platform software.

Topic signals: `api_integration`, `linux` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Strong software engineering fundamentals: clear interfaces, data models, state-machine design, error handling, testing, observability, performance debugging, and maintainable C/C++, Python, Go or Rust code.

Topic signals: `python`, `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Experience with Linux kernel internals, network device drivers, platform drivers, hwmon, I2C/SMBus, CPLDs, or board-level platform software.

Topic signals: `dns_network`, `linux` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Experience integrating or debugging Broadcom, Marvell, NVIDIA, Intel, or comparable switch ASIC SDKs and SAI implementations.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Understanding of L2/L3 forwarding, ECMP, RoCE, BGP, QoS, PFC, buffer tuning, and telemetry.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Experience with platform bring-up and board-level debugging across thermal, fan, power, transceiver, LED, watchdog, CPLD, or OSFP CMIS flows.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Experience with OpenConfig gNMI interfaces, YANG data models, or structured telemetry is helpful.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Familiarity with CI/CD pipelines, distributed config and state management, reproducible builds, and large-scale automation.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Ability to independently drive ambiguous NOS or platform feature development from problem definition through implementation, validation, rollout, and debugging across software, hardware, and vendor boundaries.

Topic signals: `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — YOU MIGHT THRIVE IN THIS ROLE IF YOU HAVE** (`EXPECTATION_CONTEXT`)

> Familiarity with Rust or Go is a plus. To comply with U.S. export control laws and regulations, candidates for this role may need to meet certain legal status requirements as provided in those laws and regulations.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 63. Applied AI Engineer, API Platform, Digital Natives

- **Posting:** https://jobs.ashbyhq.com/openai/3254f6a7-6353-4a77-beec-f37b832c99ae
- **ID:** `3254f6a7-6353-4a77-beec-f37b832c99ae` · **Source index:** 231 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 64. Applied AI Engineer, API Platform, Digital Natives

- **Posting:** https://jobs.ashbyhq.com/openai/5c3a17db-62f1-4145-93b0-2f207d4d4af8
- **ID:** `5c3a17db-62f1-4145-93b0-2f207d4d4af8` · **Source index:** 251 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 65. Applied AI Engineer, Enterprise

- **Posting:** https://jobs.ashbyhq.com/openai/01091aed-427d-4e10-8cdb-fb500cf55bb9
- **ID:** `01091aed-427d-4e10-8cdb-fb500cf55bb9` · **Source index:** 408 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 66. Data Engineering Manager, Growth &amp; Revenue

- **Posting:** https://jobs.ashbyhq.com/openai/acbf80cd-20a7-47fe-aaf9-3e9224d1570c
- **ID:** `acbf80cd-20a7-47fe-aaf9-3e9224d1570c` · **Source index:** 683 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have deep experience leading and scaling data engineering teams in a fast-moving product or technology environment.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Bring strong technical judgment across modern data systems, including SQL, Python or Scala, Spark, orchestration, dimensional and event modeling, and lakehouse or warehouse architectures.

Topic signals: `python`, `sql` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have built trusted growth, lifecycle, attribution, subscription, billing, payments, revenue, or monetization data products at meaningful scale.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Can turn ambiguous business questions into durable data contracts, metric definitions, and technical roadmaps.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Build unusually strong partnerships with Data Science, Product, Finance, Financial Engineering, GTM, and Engineering.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Care deeply about data quality, privacy, security, and the operational health of systems used for consequential decisions.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are an excellent people leader: you hire well, develop talent, give clear feedback, and create an environment where diverse perspectives do their best work. WHAT SUCCESS LOOKS LIKE

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> In the first 90 days, you have earned trust with the team and partners, clarified ownership boundaries, assessed the current data portfolio, and aligned on a prioritized roadmap.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Within a year, Growth &amp; Revenue stakeholders rely on a smaller set of trustworthy, well-owned datasets and metrics for lifecycle, attribution, subscriber, billing, payment, monetization, and revenue decisions.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> The team operates with clear goals, healthy execution rhythms, strong reliability standards, and a hiring and development plan that matches the domain’s ambition. This role is based in our San Francisco headquarters. We offer relocation assistance for new employees.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 67. Data Scientist, Business

- **Posting:** https://jobs.ashbyhq.com/openai/fc72784d-f925-4f8d-aebc-eee72e7bf55c
- **ID:** `fc72784d-f925-4f8d-aebc-eee72e7bf55c` · **Source index:** 139 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 11 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> At least 10+ years of experience in Data Science roles within dynamic, outcome-driven organizations.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Expertise in statistics and causal inference, applied in both experimentation and observational causal inference studies.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Proficiency in quantitative programming languages, such as Python and R.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Expertise in SQL, with extensive experience extracting large datasets and designing ETL workflows.

Topic signals: `automation`, `sql` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience using business intelligence tools, such as Mode, Tableau, and Looker.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strategic and impact-driven mindset, capable of translating complex business problems into actionable frameworks.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Ability to build relationships with diverse stakeholders and cultivate strong partnerships.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong communication skills, including the ability to bridge technical and non-technical stakeholders and collaborate across various functions to ensure business impact.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Ability to craft clear data stories using decks, memos, and dashboards to drive decision-making at every level.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Best-in-class attention to detail and unwavering commitment to accuracy.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Proven track record in solving problems within Finance, Marketing, Partnerships, Sales, Support, or other GTM areas.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 68. Early Access Deployment Engineer

- **Posting:** https://jobs.ashbyhq.com/openai/ee6b7ece-ffcb-4546-8b4c-ef755ec21c14
- **ID:** `ee6b7ece-ffcb-4546-8b4c-ef755ec21c14` · **Source index:** 461 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 8 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 4+ years of software engineering or equivalent technical experience, including meaningful customer-facing delivery and ownership of production systems.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have a track record of rapidly turning ambiguous ideas into working prototypes and carrying the strongest approaches through to reliable solutions. Can demonstrate examples of systems thinking.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Be proficient in Python and/or JavaScript or TypeScript, comfortable across modern front-end and back-end development, and familiar with cloud deployment.

Topic signals: `cloud`, `javascript`, `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring practical AI and LLM depth, including experience reasoning about model behavior, designing evaluations, and building production-oriented AI applications.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Exercise strong product and customer judgment by identifying the highest-value problem, scoping the right experiment, separating signal from noise, and balancing speed with technical integrity.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Own problems end to end, learn unfamiliar technical or domain concepts quickly, and impose useful structure without waiting for perfect information.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Manage several high-stakes technical engagements at once while anticipating blockers, adapting plans, and maintaining momentum across customers and internal teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Communicate complex ideas with clarity and empathy, challenge assumptions constructively, and build trust with technical and non-technical stakeholders.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 69. Firmware Engineer, RTOS, Consumer Devices

- **Posting:** https://jobs.ashbyhq.com/openai/2710d0c7-8f1c-4e1a-bf7a-4000fc5a8d68
- **ID:** `2710d0c7-8f1c-4e1a-bf7a-4000fc5a8d68` · **Source index:** 157 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have deep experience shipping embedded systems (around 10+ years).

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are proficient in C and C++.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are familiar with embedded toolchains, operating systems, and debugging tools.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience with both rapid prototyping and scalable product development.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> (Nice to have) Have experience with Zephyr RTOS.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> (Nice to have) Have worked with networking/wireless stacks (BLE, Wi-Fi).

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> (Nice to have) Have experience with Linux kernel development.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 70. Product Marketing Manager, Cybersecurity

- **Posting:** https://jobs.ashbyhq.com/openai/9c990e11-a5fb-4c6d-ab83-ede32839e78e
- **ID:** `9c990e11-a5fb-4c6d-ab83-ede32839e78e` · **Source index:** 566 · **Broad band:** `DEEP_REVIEW_PRIORITY`
- **Geography:** `RELOCATION_DEPENDENT` / `US_RELOCATION_ASSISTANCE_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 15 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_terms_and_amount_not_confirmed`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 7+ years of experience in product marketing, industry marketing, cybersecurity marketing, enterprise GTM, or an adjacent B2B technology role.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have marketed technical enterprise products to security, developer, IT, risk, or C-suite audiences.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can translate complex model, product, and security concepts into clear positioning, field assets, and customer-facing narratives.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong cross-functional program leadership instincts and can drive work across Product, GTM, Communications, Partnerships, Policy, Security, and Research.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Use customer evidence, field signals, product usage, market research, and competitive context to sharpen strategy and prioritize work.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have built GTM programs, operating rhythms, or new playbooks in ambiguous, high-velocity environments.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring strong writing, messaging, and editorial judgment, with a high bar for clarity, quality, accuracy, and credibility.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are deeply curious about cybersecurity, AI, software development, enterprise adoption, and how new capabilities become meaningful customer value.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Think strategically about how industry marketing drives awareness, trust, pipeline, adoption, customer proof, and long-term market leadership.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are highly collaborative and effective at influencing senior stakeholders, field teams, technical teams, and external partners.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Execute quickly while maintaining a high quality bar across messaging, launches, enablement, customer proof, and campaigns.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R012 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience in cybersecurity areas such as application security, SecOps, cloud security, vulnerability management, detection and response, or secure software development.

Topic signals: `cloud`, `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience with AI, developer tools, cloud infrastructure, API platforms, or enterprise software.

Topic signals: `api_integration`, `cloud` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R014 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have supported enterprise account-based marketing, executive events, customer stories, partner marketing, or field enablement.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R015 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are familiar with CISOs, security practitioners, enterprise governance, procurement, and high-trust customer environments. Workplace &amp; Location This role is based in San Francisco, CA. We use a hybrid work model of three days in the office per week and offer relocation assistance to new employees.

Topic signals: `customer_communication`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 71. Dedicated Support Engineer - San Francisco

- **Posting:** https://jobs.ashbyhq.com/openai/2348230a-295f-434d-9b16-653e01ddbd0b
- **ID:** `2348230a-295f-434d-9b16-653e01ddbd0b` · **Source index:** 699 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 11 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have significant experience in Support Engineering, Solutions Engineering, Solutions Architecture, or another role involving hands-on diagnosis of complex production issues.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have expert-level troubleshooting skills and a strong track record of resolving ambiguous technical problems across APIs, distributed systems, cloud infrastructure, and enterprise integrations.

Topic signals: `api_integration`, `cloud`, `distributed_systems`, `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `SKILLS_LIST`, `CERT_IT`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable working with logs, metrics, traces, API requests, authentication flows, and customer-provided code or configurations to understand system behavior and test hypotheses.

Topic signals: `api_integration`, `customer_communication`, `testing` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience leading or playing a central role in customer-impacting incidents, including severity assessment, technical coordination, stakeholder communication, root-cause analysis, and post-incident follow-through.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can write code or scripts to reproduce issues, interrogate systems, automate repetitive work, and improve internal tools. Experience with Python, JavaScript, or similar languages is valuable.

Topic signals: `automation`, `javascript`, `python` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can communicate complex technical issues clearly to engineers, customer technical teams, business stakeholders, and senior leaders—especially when information is incomplete or evolving.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Build strong, high-trust relationships with customers and cross-functional partners while maintaining clear and scalable ownership boundaries.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Look beyond the immediate issue to identify patterns, improve the system, and prevent the same problem from recurring.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Thrive in ambiguity, update quickly as new information emerges, and are willing to learn whatever is needed to get the job done.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring a humble, team-first mindset, strong judgment, and a genuine eagerness to help both customers and colleagues succeed.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are excited to use OpenAI’s products, agents, and emerging AI capabilities to transform how technical support operates at scale.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 72. Software Engineer, Compute Infrastructure

- **Posting:** https://jobs.ashbyhq.com/openai/ca300a6d-a2a7-4580-aad7-323fbdfee7b1
- **ID:** `ca300a6d-a2a7-4580-aad7-323fbdfee7b1` · **Source index:** 286 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 12 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have built or operated distributed systems, infrastructure platforms, high-performance computing environments, large-scale networking systems, Kubernetes clusters, developer tools, or production systems with demanding reliability requirements

Topic signals: `cloud`, `distributed_systems`, `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Enjoy working across layers of the stack and are comfortable moving between software, hardware, networking, systems performance, reliability, and user needs

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Care about making complex infrastructure understandable, observable, and usable for the people depending on it

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can diagnose hard problems under real operational pressure while still investing in long-term engineering quality

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Like building leverage for others, whether through APIs, automation, debugging tools, CaaS and agent infrastructure primitives, workflow improvements, or better platform abstractions

Topic signals: `api_integration`, `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are motivated by scale, efficiency, reliability, and disciplined measurement through benchmarks, profiles, and production evidence

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Communicate clearly, take ownership, and work well with teams whose constraints and goals differ from your own

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — Qualifications** (`EXPECTATION_CONTEXT`)

> Strong software engineering skills and experience building, operating, or improving production infrastructure systems

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — Qualifications** (`EXPECTATION_CONTEXT`)

> Experience in one or more relevant areas such as distributed systems, operating systems, networking protocols, RDMA, NCCL or collective communication, storage, Kubernetes, scheduling, observability, reliability engineering, high-performance computing, GPU infrastructure, CaaS, agent infrastructure, hardware-aware performance optimization, benchmarking, developer experience, or infrastructure tooling

Topic signals: `cloud`, `customer_communication`, `distributed_systems`, `dns_network` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — Qualifications** (`EXPECTATION_CONTEXT`)

> Ability to debug complex system behavior across software, hardware, networking, and workload layers, then turn findings into robust improvements

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — Qualifications** (`EXPECTATION_CONTEXT`)

> Comfort with ambiguity, strong ownership, and a bias toward practical, durable solutions

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — Qualifications** (`EXPECTATION_CONTEXT`)

> Interest in working on infrastructure that directly enables frontier AI research and product impact

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 73. AI Support Engineer - San Francisco

- **Posting:** https://jobs.ashbyhq.com/openai/1a979fd4-1bce-484e-a416-aed2810677a6
- **ID:** `1a979fd4-1bce-484e-a416-aed2810677a6` · **Source index:** 82 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `numeric_experience_not_verified`, `degree_or_equivalent_not_verified`, `relocation_funding_not_established`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Have 8+ years of experience in User Operations, Engineering, Support Engineering or similar technical roles, ideally within high-growth tech startups or other fast-paced environments.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Are comfortable using emerging technologies (ie. Codex, ChatGPT, OpenAI API, etc.) to script or engineer code (e.g., Python) for automating repetitive tasks and integrating tools.

Topic signals: `api_integration`, `automation`, `python` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Have expert-level SaaS troubleshooting skills with the ability to rapidly understand new technologies and complex concepts.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Polished enterprise communication and are calm with high-stakes customers during live incident calls

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Proven experience building strong relationships with customers and cross-functional partners to drive resolution to complex issues.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Exceptional critical thinker and problem solver with the ability to clearly communicate complex technical issues to both customers and internal teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Thrive in ambiguity, adapt rapidly to change, continuously learn, and proactively seek opportunities for growth.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Bring a humble, team first mindset, a genuine eagerness to help others, and the curiosity to quickly learn whatever knowledge is needed to help both your teammates and our customers succeed.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Bachelor’s degree in Computer Science, Computer Engineering, another relevant technical field, or equivalent practical experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **EDUCATION NOT VERIFIED**

### 74. AI Support Engineer - San Francisco (Weekend Shift)

- **Posting:** https://jobs.ashbyhq.com/openai/99f823a1-66ec-44bd-ba30-d3645aa49d74
- **ID:** `99f823a1-66ec-44bd-ba30-d3645aa49d74` · **Source index:** 180 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 9 lines
- **Review flags:** `numeric_experience_not_verified`, `degree_or_equivalent_not_verified`, `relocation_funding_not_established`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Have 8+ years of experience in User Operations, Engineering, Support Engineering or similar technical roles, ideally within high-growth tech startups or other fast-paced environments.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Are comfortable using emerging technologies (ie. Codex, ChatGPT, OpenAI API, etc.) to script or engineer code (e.g., Python) for automating repetitive tasks and integrating tools.

Topic signals: `api_integration`, `automation`, `python` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Have expert-level SaaS troubleshooting skills with the ability to rapidly understand new technologies and complex concepts.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Polished enterprise communication and are calm with high-stakes customers during live incident calls

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Proven experience building strong relationships with customers and cross-functional partners to drive resolution to complex issues.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Exceptional critical thinker and problem solver with the ability to clearly communicate complex technical issues to both customers and internal teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Thrive in ambiguity, adapt rapidly to change, continuously learn, and proactively seek opportunities for growth.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Bring a humble, team first mindset, a genuine eagerness to help others, and the curiosity to quickly learn whatever knowledge is needed to help both your teammates and our customers succeed.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Bachelor’s degree in Computer Science, Computer Engineering, another relevant technical field, or equivalent practical experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **EDUCATION NOT VERIFIED**

### 75. Operating Systems Engineer \| Consumer Devices

- **Posting:** https://jobs.ashbyhq.com/openai/efed424b-e025-400f-8ac3-73e962b85751
- **ID:** `efed424b-e025-400f-8ac3-73e962b85751` · **Source index:** 215 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 20 lines
- **Review flags:** `relocation_funding_not_established`

**R001 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Strong experience with systems programming (such as with Linux, BSD, etc), including meaningful work in the kernel (drivers, core subsystems, or platform enablement) and operating systems.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Professional proficiency in C, C++ for low-level systems development.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Experience building or maintaining core OS services and platform software (system services, daemons, init/service management, device management, logging/telemetry pipelines).

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Track record of debugging complex issues across kernel/userspace boundaries using tracing, profiling, and structured root cause analysis.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Familiarity with security fundamentals in OS design: isolation boundaries, privilege separation, secure IPC, attack surface reduction, and vulnerability mitigation practices. STRONGLY PREFERRED

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Production experience with Rust in systems contexts (kernel-adjacent tooling, userspace services, security-sensitive components, or performance-critical libraries).

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Experience with OS security hardening: SELinux/AppArmor policy, sandboxing, seccomp, namespaces/cgroups, secure boot chains, exploit mitigations.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Experience setting up and operationalizing observability: eBPF-based tooling, perf pipelines, automated regression detection.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Performance and power optimization experience, including measurement methodology (power rails, battery instrumentation, thermal constraints) and closed-loop tuning.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — REQUIRED QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Experience supporting application or UI frameworks at the OS boundary (Wayland/compositors, graphics pipeline performance, input latency, lifecycle/permission models).

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> Hardware bring-up exposure (bootloader/early boot debugging, device tree/ACPI, board revisions, peripheral enablement), even if not your primary background.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> Experience with OTA/update systems, partitioning strategies, rollback/health checks, and update security (signing, provenance).

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> Experience contributing to upstream open source projects (Linux kernel, system components) and managing long-lived downstream patches responsibly. WHAT SUCCESS LOOKS LIKE

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R014 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> The OS is secure by default, privacy-preserving, and designed for least privilege.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R015 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> Performance and power characteristics are measurable, repeatable, and continuously improved with low regression rates.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R016 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> Debugging is fast: tracing, logs, crash artifacts, and metrics make issues diagnosable in development and in the field.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R017 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> Application and UI teams have stable, well-documented system interfaces that enable high-quality product experiences. WORKING STYLE

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R018 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> You take ownership across boundaries: kernel, services, tooling, and the interfaces that applications rely on.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R019 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> You are comfortable making careful tradeoffs between security, privacy, performance, power, and developer velocity.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R020 — NICE TO HAVE** (`PREFERRED_CONTEXT`)

> You communicate clearly with partner teams and can translate low-level findings into actionable changes.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 76. Operating Systems Engineer, Connectivity &amp; Networking \| Consumer Devices

- **Posting:** https://jobs.ashbyhq.com/openai/c5f39beb-dc8a-4f43-a156-28754d306f64
- **ID:** `c5f39beb-dc8a-4f43-a156-28754d306f64` · **Source index:** 214 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 17 lines
- **Review flags:** `relocation_funding_not_established`

**R001 — MINIMUM QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Substantial hands-on experience developing Wi-Fi and Bluetooth functionality in operating-system frameworks, system services, or connectivity middleware.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — MINIMUM QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Strong understanding of IP networking, including IPv4/IPv6, TCP/UDP, DNS, DHCP, routing, and socket behavior, with practical experience implementing and debugging networked systems.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — MINIMUM QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Experience implementing advanced networking capabilities in one or more areas such as routing and network policy, VPNs and tunneling, traffic management, or network isolation.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — MINIMUM QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Experience designing and maintaining platform APIs and the services behind them, including connection lifecycle management and integration with other OS components.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — MINIMUM QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Proficiency in C++ for systems development, including concurrent programming, memory ownership, and resource lifetime management.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — MINIMUM QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Strong understanding of asynchronous systems, interprocess communication, and failure handling.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — MINIMUM QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Experience diagnosing complex connectivity issues using system traces, protocol captures, logs, and structured debugging.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — MINIMUM QUALIFICATIONS** (`STATED_REQUIREMENT_CONTEXT`)

> Ability to work across disciplines, make sound technical tradeoffs, and carry solutions from investigation through implementation and validation.

Topic signals: `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have delivered connectivity capabilities in shipped products and resolved interoperability issues across software stacks and third-party implementations.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Bring depth in transport protocols and performance, including QUIC, congestion control, multi-path networking, or operation across multiple network interfaces.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have experience with network virtualization, proxies, NAT, firewalls, or policy enforcement within an operating system.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R012 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have improved connectivity performance or power consumption, supported by repeatable measurements and regression coverage.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Understand security and privacy considerations in connectivity services, including authentication, permissions, and credential handling.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R014 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are proficient in Rust for systems programming.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R015 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Take ownership of complete solutions and follow problems across framework, service, and underlying stack boundaries.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R016 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Use experiments and measurements to challenge assumptions and guide technical decisions.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R017 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Work constructively across disciplines and make careful tradeoffs among functionality, security, reliability, performance, power, and maintainability.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 77. Software Engineer, API Enterprise Controls

- **Posting:** https://jobs.ashbyhq.com/openai/4c0a6cb6-d365-4e5b-bdff-c093d951026d
- **ID:** `4c0a6cb6-d365-4e5b-bdff-c093d951026d` · **Source index:** 482 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_funding_not_established`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 78. Software Engineer, API Multicloud

- **Posting:** https://jobs.ashbyhq.com/openai/4070d52e-0263-4cd5-9107-052b4ecc1209
- **ID:** `4070d52e-0263-4cd5-9107-052b4ecc1209` · **Source index:** 353 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_funding_not_established`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 79. Software Engineer, Codex Core Agents

- **Posting:** https://jobs.ashbyhq.com/openai/7ade7a12-845c-4e3a-af23-c028420bd181
- **ID:** `7ade7a12-845c-4e3a-af23-c028420bd181` · **Source index:** 238 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_funding_not_established`

**R001 — Bonus Points** (`PREFERRED_CONTEXT`)

> Experience with code execution platforms, CI/CD systems, or build systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — Bonus Points** (`PREFERRED_CONTEXT`)

> Experience coding in Rust

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — Bonus Points** (`PREFERRED_CONTEXT`)

> Familiarity with LLMs, agents, or tool-use frameworks.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — Bonus Points** (`PREFERRED_CONTEXT`)

> Background in security engineering or isolation systems.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — Bonus Points** (`PREFERRED_CONTEXT`)

> Experience building developer platforms, IDE tooling, or open source infrastructure.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 80. Software Engineer, Compute Foundations Systems

- **Posting:** https://jobs.ashbyhq.com/openai/770d5c3f-4e72-4b49-aec4-d444e8ad7a64
- **ID:** `770d5c3f-4e72-4b49-aec4-d444e8ad7a64` · **Source index:** 33 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 11 lines
- **Review flags:** `relocation_funding_not_established`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have significant experience building, integrating, or operating production Linux systems, particularly Ubuntu, Debian, or another major Linux distribution.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have deep experience in one or more of: Linux kernels, modules, or device drivers; Linux distribution, package, repository, or OS-image engineering; boot, provisioning, disks, or machine configuration; firmware and driver integration, qualification, or rollout.

Topic signals: `api_integration`, `linux` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Can write, debug, and maintain production-quality systems software and automation using appropriate systems languages, scripting, and Linux tooling.

Topic signals: `automation`, `linux` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Understand how to build, test, package, qualify, and safely deliver system-level changes, including compatibility testing, staged rollout, rollback, and recovery.

Topic signals: `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Can systematically debug failures that cross hardware, firmware, boot, operating-system, kernel, and driver boundaries, and collaborate effectively with hardware and software partners.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Enjoy investigating difficult system behavior, identifying underlying failure modes, and building pragmatic fixes that make production systems more reliable. BONUS POINTS IF YOU:

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have built bare-metal provisioning, machine-bootstrap, OS-reprovisioning, or system-lifecycle tooling.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have worked with GPU systems, AI infrastructure, HPC clusters, accelerators, or other heterogeneous and performance-sensitive compute environments.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have experience bringing up new server platforms or working directly with hardware and software vendors on firmware, driver, or operating-system compatibility issues.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have contributed to Linux, kernel subsystems or modules, distributions, package ecosystems, drivers, firmware tooling, or other open-source systems software.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have delivered or supported system-software changes across large production compute fleets.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 81. Software Engineer, Enterprise Verticals

- **Posting:** https://jobs.ashbyhq.com/openai/3229b152-015f-49ad-9921-9c9de95570c8
- **ID:** `3229b152-015f-49ad-9921-9c9de95570c8` · **Source index:** 467 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 13 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF:** (`EXPECTATION_CONTEXT`)

> You are a strong product engineer with excellent product judgment.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF:** (`EXPECTATION_CONTEXT`)

> You are comfortable moving across frontend, backend, APIs, data, and systems integration.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF:** (`EXPECTATION_CONTEXT`)

> You communicate clearly with customers and cross-functional partners.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF:** (`EXPECTATION_CONTEXT`)

> You use evidence and tests to make ambiguous work observable.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF:** (`EXPECTATION_CONTEXT`)

> You care about enterprise permissions, reliability, privacy, and rollout safety.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF:** (`EXPECTATION_CONTEXT`)

> You have shipped a user-facing product through ambiguity and can explain the decisions, tradeoffs, and evidence behind it.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF:** (`EXPECTATION_CONTEXT`)

> You can translate a concrete customer workflow into a general product without losing the details that make the first experience useful.

Topic signals: `automation`, `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R008 — PREFERRED QUALIFICATIONS:** (`PREFERRED_CONTEXT`)

> Experience building and operating full-stack production products across a modern frontend stack (such as React/TypeScript) and backend services (such as Python, Go, Node.js, or comparable technologies).

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — PREFERRED QUALIFICATIONS:** (`PREFERRED_CONTEXT`)

> Experience designing evolvable APIs, data models, and distributed or integration-heavy systems, including authentication, identity, permissions, secure data flows, and partial-failure behavior.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — PREFERRED QUALIFICATIONS:** (`PREFERRED_CONTEXT`)

> Experience owning production systems at scale, including observability, performance, testing, incident response, safe migrations, staged rollout, and rollback.

Topic signals: `security`, `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — PREFERRED QUALIFICATIONS:** (`PREFERRED_CONTEXT`)

> Experience building applied-AI or conversational products and evaluating probabilistic behavior with grounding, quality signals, and human-feedback loops.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — PREFERRED QUALIFICATIONS:** (`PREFERRED_CONTEXT`)

> Experience building dashboards, data visualizations, or workflow and insight products that make complex information understandable and actionable.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R013 — PREFERRED QUALIFICATIONS:** (`PREFERRED_CONTEXT`)

> Familiarity with experimentation, product metrics, and iterative development, including instrumenting user outcomes from first use through retained usage.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 82. Software Engineer, GPT Infrastructure

- **Posting:** https://jobs.ashbyhq.com/openai/f3ddd41c-541f-485e-90d6-86c26e018e9f
- **ID:** `f3ddd41c-541f-485e-90d6-86c26e018e9f` · **Source index:** 285 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 14 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — Qualifications** (`EXPECTATION_CONTEXT`)

> Strong software engineering experience building distributed systems, infrastructure platforms, production services, developer platforms, or orchestration systems.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — Qualifications** (`EXPECTATION_CONTEXT`)

> Proficiency in one or more systems-oriented languages such as Python, C++, Go, or Rust.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — Qualifications** (`EXPECTATION_CONTEXT`)

> Experience designing and operating APIs, job orchestration systems, durable workflows, or large-scale backend services.

Topic signals: `api_integration`, `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — Qualifications** (`EXPECTATION_CONTEXT`)

> Strong understanding of Linux, networking, storage, containers, distributed execution, and modern infrastructure architectures.

Topic signals: `dns_network`, `linux` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — Qualifications** (`EXPECTATION_CONTEXT`)

> Ability to reason about model execution and diagnose problems across software and hardware boundaries.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — Qualifications** (`EXPECTATION_CONTEXT`)

> Experience using profiling, tracing, benchmarking, and measurement to guide engineering decisions.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — Qualifications** (`EXPECTATION_CONTEXT`)

> Strong ownership and the ability to work effectively across research, engineering, security, product, and external-partner teams. Preferred Skills

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — Qualifications** (`EXPECTATION_CONTEXT`)

> Experience with AI infrastructure, model inference, distributed ML systems, or inference-serving platforms.

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — Qualifications** (`EXPECTATION_CONTEXT`)

> Familiarity with GPU or accelerator architecture, memory hierarchies, interconnects, collective communication, and distributed model execution.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — Qualifications** (`EXPECTATION_CONTEXT`)

> Experience with compilers, runtimes, kernels, or performance engineering using technologies such as CUDA, ROCm, Triton, LLVM, or MLIR.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — Qualifications** (`EXPECTATION_CONTEXT`)

> Familiarity with inference engines or serving systems such as vLLM, SGLang, Triton Inference Server, or comparable internal systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — Qualifications** (`EXPECTATION_CONTEXT`)

> Experience with model partitioning, sharding, tensor or expert parallelism, and compute–communication tradeoffs.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R013 — Qualifications** (`EXPECTATION_CONTEXT`)

> Experience building remote-execution systems, secure partner-facing infrastructure, evaluation harnesses, or artifact pipelines.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R014 — Qualifications** (`EXPECTATION_CONTEXT`)

> Experience with automated optimization, search systems, coding agents, or evaluator-driven systems that iteratively improve kernels or runtime configurations.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 83. Software Engineer, Healthcare

- **Posting:** https://jobs.ashbyhq.com/openai/4923fd3e-acf2-4551-91ad-5a92ca81455b
- **ID:** `4923fd3e-acf2-4551-91ad-5a92ca81455b` · **Source index:** 670 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 19 lines
- **Review flags:** `numeric_experience_not_verified`, `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are a strong backend or full-stack engineer who enjoys building durable production systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 5+ years of experience writing maintainable, production-quality software.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **YEARS NOT VERIFIED**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong experience with backend services, APIs, data systems, or distributed systems.

Topic signals: `api_integration`, `distributed_systems` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable reasoning about system architecture, data models, authentication, permissions, and integration boundaries.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience owning production systems at scale, including observability, testing, incident response, migrations, and rollout.

Topic signals: `security`, `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can move between product requirements and technical architecture without losing ownership of either.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Operate with high agency and are comfortable taking ambiguous problems from definition through production.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Enjoy working directly with cross-functional partners and customers to understand complex workflows.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Care deeply about reliability, privacy, security, and correctness.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are motivated by the opportunity to improve healthcare through AI.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience building enterprise SaaS products or platforms.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience with distributed systems, backend architecture, or large-scale data pipelines.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience building integrations with complex third-party systems or APIs.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R014 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience with authentication, identity, permissions, or enterprise security.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R015 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience working in regulated industries such as healthcare, finance, or enterprise infrastructure.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R016 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience with healthcare interoperability, EHR systems, or healthcare data standards.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R017 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience building HIPAA-compliant products or systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R018 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience building applied AI or conversational products.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R019 — Nice to have:** (`PREFERRED_CONTEXT`)

> Previous experience in healthcare or health technology.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 84. Software Engineer, Implicit Signals

- **Posting:** https://jobs.ashbyhq.com/openai/c7bcdaec-9714-44b0-8ba8-adc824594b54
- **ID:** `c7bcdaec-9714-44b0-8ba8-adc824594b54` · **Source index:** 761 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 8 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience designing, building, and operating software services or distributed systems at scale.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong fundamentals in API design, concurrency, caching, performance, and failure recovery.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Ability to investigate complex production problems and make sound architectural tradeoffs.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A track record of owning software from initial design through deployment and ongoing operation.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong product judgment and an interest in working directly with technical users.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Comfort with ambiguous problems and broad ownership across multiple parts of a system.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Fluency in using AI agents to move quickly across multiple workstreams in a fast-paced environment.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Interest in machine learning, data science, and statistics; experience with model serving, ML platforms, or inference optimization is a plus.

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 85. Software Engineer, Infrastructure - Analytics Platform

- **Posting:** https://jobs.ashbyhq.com/openai/e44bfa94-0b82-4d0c-b224-02155b76eea9
- **ID:** `e44bfa94-0b82-4d0c-b224-02155b76eea9` · **Source index:** 248 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have owned a critical distributed system or research platform end to end and can explain how you took it from an ambiguous problem to reliable production adoption.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have experience with high performing programing languages (Rust or C++), including performance profiling, concurrency, async execution, memory behavior, serialization, I/O, networking, and failure analysis.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Bring deep expertise in at least one relevant area such as distributed databases, storage engines, analytics systems, telemetry, logging, search, ingestion, or query execution.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Can reason carefully about partitioning, replication, consistency, retries, backpressure, event lineage, duplicate or delayed data, overload, migrations, and failure isolation.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have experience with ClickHouse or similar OLAP, columnar, time-series, or high-throughput analytical systems. Direct ClickHouse experience is helpful but not required.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Bring strong computer science fundamentals and algorithmic reasoning. Competitive-programming experience is welcome but not required.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Already use coding agents regularly and have opinions about how AI tools change software development, product interfaces, and engineering leverage.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Enjoy working directly with researchers and other highly technical users: understanding their constraints, debugging ambiguous problems, explaining tradeoffs, and closing the loop after shipping.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have the judgment to focus on the largest practical bottleneck rather than expanding every project into a complete platform rewrite.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Are a strong engineer first. Clear communication and business judgment are non-negotiable, but your credibility comes from building and operating systems that work. WHY THIS WORK MATTERS Researchers need reliable ways to understand model quality, behavior, and reasoning across frontier training and evaluation workflows. When analytics are slow, unavailable, or unable to express a new question, research slows with them. The systems you build will help researchers move from raw metrics, samples, traces, and model outputs to useful understanding. Better latency, reliability, and reusable platform capabilities can compound across hundreds of researchers and many of OpenAI’s most important research efforts.

Topic signals: `automation`, `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 86. Software Engineer, Monetization Data Systems

- **Posting:** https://jobs.ashbyhq.com/openai/d2aad13c-6ed0-4905-ae12-8ea2397b190c
- **ID:** `d2aad13c-6ed0-4905-ae12-8ea2397b190c` · **Source index:** 458 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 14 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Possess a minimum of 7+ years of professional software engineering experience with deep experience building and operating production software systems, backend services, or distributed systems at scale.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are highly proficient in at least one general-purpose programming language such as Go, Java, Python, Rust, or C++, with strong computer science fundamentals.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong fundamentals in API design, data modeling, storage systems, distributed systems, and event-driven architecture.

Topic signals: `api_integration`, `distributed_systems` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have designed systems with rigorous correctness, reliability, observability, security, privacy, or access-control requirements.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can collaborate with cross-functional partners to identify needs, navigate ambiguity, and drive progress from problem definition through delivery.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring a product-oriented mindset and communicate clearly with technical and non-technical partners, translating customer and business problems into simple, scalable system designs.

Topic signals: `customer_communication`, `distributed_systems` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Care deeply about correctness and operational reliability while maintaining a practical bias toward delivering customer and business value.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring a strong sense of engineering excellence, using clear thinking, sound judgment, and a design-before-implementation approach to create maintainable systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Command strong sense of engineering excellence, contribute to a design-before-implementation approach with clear documentation, and knowledge sharing across teams to elevate the broader engineering organization.

Topic signals: `documentation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience with monetization, pricing, billing, ads, payments, entitlements, subscriptions, or other financial products.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — Nice to have:** (`PREFERRED_CONTEXT`)

> Familiarity with financial correctness, reconciliation, compliance, or audit requirements.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience with high-scale distributed systems, transactional workflows, event streaming, or payment infrastructure.

Topic signals: `automation`, `distributed_systems` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R013 — Nice to have:** (`PREFERRED_CONTEXT`)

> Experience building internal platforms, shared frameworks, APIs, or developer tooling used by other engineering teams.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R014 — Nice to have:** (`PREFERRED_CONTEXT`)

> Monetization or finance domain experience is helpful but not required. We value strong software engineering judgment, systems thinking, and the ability to learn a complex domain quickly.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 87. AI Support Engineer, Biosciences - San Francisco

- **Posting:** https://jobs.ashbyhq.com/openai/759dd316-cbe9-4e73-af57-808502568b29
- **ID:** `759dd316-cbe9-4e73-af57-808502568b29` · **Source index:** 442 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 14 lines
- **Review flags:** `numeric_experience_not_verified`, `degree_or_equivalent_not_verified`, `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 8+ years of experience in technical support, support engineering, escalations, technical account management, solutions operations, product operations, incident management, or a related customer-facing technical role.

Topic signals: `customer_communication`, `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF** · **YEARS NOT VERIFIED**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring meaningful familiarity with life sciences disciplines or workflows, such as computational biology, bioinformatics, genomics, transcriptomics, drug discovery, or related fields.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Can rapidly understand and triage questions involving scientific tools and workflows while recognizing when specialized scientific expertise is required.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have 8+ years of experience in User Operations, Engineering, Support Engineering or similar technical roles, ideally within high-growth tech startups or other fast-paced environments.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF** · **YEARS NOT VERIFIED**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable using emerging technologies (ie. Codex, ChatGPT, OpenAI API, etc.) to script or engineer code (e.g., Python) for automating repetitive tasks and integrating tools.

Topic signals: `api_integration`, `automation`, `python` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have expert-level SaaS troubleshooting skills with the ability to rapidly understand new technologies and complex concepts.

Topic signals: `technical_support` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_IT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Demonstrate polished enterprise communication: calm with high-stakes customers during live incident calls and proven experience building strong relationships with customers and cross-functional partners to drive resolution to complex issues.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Exceptional critical thinker and problem solver with the ability to clearly communicate complex technical issues to both customers and internal teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Thrive in ambiguity, adapt rapidly to change, continuously learn, and proactively seek opportunities for growth.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bring a humble, team first mindset, a genuine eagerness to help others, and the curiosity to quickly learn whatever knowledge is needed to help both your teammates and our customers succeed.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Bachelor’s degree in Computer Science, Computer Engineering, another relevant technical field, or equivalent practical experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **EDUCATION NOT VERIFIED**

**R012 — Preferred qualifications** (`PREFERRED_CONTEXT`)

> Experience supporting software, data, or AI products used in regulated or security-sensitive scientific environments.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — Preferred qualifications** (`PREFERRED_CONTEXT`)

> Experience working with computational research environments, scientific software, cloud platforms, APIs, or data-intensive workflows.

Topic signals: `api_integration`, `automation`, `cloud` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R014 — Preferred qualifications** (`PREFERRED_CONTEXT`)

> A degree or equivalent practical experience in a life sciences, computational, engineering, or other relevant technical field.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE** · **EDUCATION NOT VERIFIED**

### 88. AI Systems Engineer, Codex Agents

- **Posting:** https://jobs.ashbyhq.com/openai/de06790a-7243-4e33-a6f1-e7bd34009588
- **ID:** `de06790a-7243-4e33-a6f1-e7bd34009588` · **Source index:** 318 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_funding_not_established`

**R001 — Bonus Points** (`PREFERRED_CONTEXT`)

> Deep Rust, systems, sandboxing, isolation, or low-level platform experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — Bonus Points** (`PREFERRED_CONTEXT`)

> Experience with coding agents, agent harnesses, tool-using LLM systems, model evals, or post-training feedback loops.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — Bonus Points** (`PREFERRED_CONTEXT`)

> Background in compilers, kernels, runtimes, inference optimization, GPU systems, benchmarking, profiling, or performance engineering.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — Bonus Points** (`PREFERRED_CONTEXT`)

> Experience building production infrastructure used by many engineers or users under demanding reliability and security constraints.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — Bonus Points** (`PREFERRED_CONTEXT`)

> Open-source infrastructure or developer-platform work with strong taste for APIs and usability.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 89. Applied AI Software Engineer, GTM Growth Engineering

- **Posting:** https://jobs.ashbyhq.com/openai/38e3c4bf-a632-405e-9619-b87382ca2472
- **ID:** `38e3c4bf-a632-405e-9619-b87382ca2472` · **Source index:** 462 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 5 lines
- **Review flags:** `relocation_funding_not_established`

**R001 — Nice to Have** (`PREFERRED_CONTEXT`)

> Experience building agent evaluation, observability, experimentation, or AI infrastructure products.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — Nice to Have** (`PREFERRED_CONTEXT`)

> Experience with production replay, LLM grading, human-labeled datasets, shadow evaluation, or staged rollout.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — Nice to Have** (`PREFERRED_CONTEXT`)

> Experience improving model or agent behavior through context design, prompting, tools, decision logic, or feedback loops.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — Nice to Have** (`PREFERRED_CONTEXT`)

> Experience with sales, B2B marketing, revenue, CRM, campaign, or other GTM-facing systems.

Topic signals: `crm` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — Nice to Have** (`PREFERRED_CONTEXT`)

> Experience measuring customer engagement, qualified pipeline, conversion, or operational efficiency.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 90. Full Stack Software Engineer, API Experience

- **Posting:** https://jobs.ashbyhq.com/openai/66288824-8b77-4774-bc57-6825d3e6221e
- **ID:** `66288824-8b77-4774-bc57-6825d3e6221e` · **Source index:** 357 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_funding_not_established`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 91. Full Stack Software Engineer, ChatGPT Finances

- **Posting:** https://jobs.ashbyhq.com/openai/39e06ef9-5e62-425d-81e2-e8690188011f
- **ID:** `39e06ef9-5e62-425d-81e2-e8690188011f` · **Source index:** 374 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 18 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have experience building and shipping full-stack consumer products in production.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Are comfortable working in a modern frontend stack and building the APIs and services behind it.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Care deeply about product craftsmanship, performance, accessibility, and details that affect the user experience.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Understand API design, data modeling, system reliability, and the tradeoffs involved in evolving production systems.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Can move effectively between frontend, backend, and product decisions rather than remaining in a narrow implementation area.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Have strong product judgment and can take a feature from a rough idea to a shipped, measurable outcome.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Work well in ambiguous, high-impact areas where the product and technical architecture are still taking shape.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Think carefully about privacy, security, reliability, and user trust when working with sensitive data.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Enjoy diagnosing problems across system boundaries and improving the underlying engineering foundations.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — YOU MIGHT THRIVE IN THIS ROLE IF YOU** (`EXPECTATION_CONTEXT`)

> Are interested in AI-native interfaces and new ways to make complex personal information easier to understand.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R011 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Experience building backend services using languages and frameworks such as Python, Go, Node.js, or comparable technologies.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R012 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Experience with frontend development using React / Typescript, or Swift or Kotlin.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Experience operating consumer products or distributed systems at scale.

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R014 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Experience with fintech, personal finance, banking, payments, investing, or sensitive-data domain.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R015 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Familiarity with authentication, identity, permissions, privacy, and secure data flows.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R016 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Experience building dashboards, data visualizations, or insight-oriented products.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R017 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Familiarity with observability, experimentation, product metrics, and iterative development.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R018 — PREFERRED QUALIFICATIONS** (`PREFERRED_CONTEXT`)

> Experience with applied AI, conversational interfaces, or systems that incorporate model-generated output.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 92. Full Stack Software Engineer, ChatGPT ImageGen

- **Posting:** https://jobs.ashbyhq.com/openai/6b47238e-025a-4350-b270-2f3564002fcc
- **ID:** `6b47238e-025a-4350-b270-2f3564002fcc` · **Source index:** 365 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience building and shipping production-grade applications across both frontend and backend systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are comfortable working with modern web technologies such as React, TypeScript, and contemporary frontend frameworks.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience building scalable backend services, APIs, and distributed systems.

Topic signals: `api_integration`, `distributed_systems` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Enjoy owning products end-to-end and can seamlessly move between user experience challenges and infrastructure decisions.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong product instincts and enjoy thinking deeply about how users interact with technology.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are highly analytical and comfortable using experimentation, metrics, and user feedback to drive decision-making.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Thrive in fast-moving environments where priorities evolve quickly and new opportunities emerge constantly.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Enjoy collaborating with cross-functional partners including researchers, designers, product managers, and data scientists.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are excited by multimodal AI and motivated by the opportunity to define entirely new ways for people to create and communicate visually.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have experience with media platforms, creative tools, image processing, content creation products, or AI-powered applications (a plus). Why this role is unique Image Generation sits at the center of some of the most exciting advances happening in AI today. As a Full Stack Engineer on the team, you'll have the opportunity to work across the entire product surface, influence both user experience and technical architecture, and help bring cutting-edge multimodal research to hundreds of millions of users. The problems are highly visible, technically challenging, and deeply impactful—spanning product innovation, distributed systems, AI integration, and large-scale user experiences.

Topic signals: `api_integration`, `distributed_systems` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 93. Full Stack Software Engineer, Codex

- **Posting:** https://jobs.ashbyhq.com/openai/5ebd5f66-75db-4a96-8d39-babc14f1c582
- **ID:** `5ebd5f66-75db-4a96-8d39-babc14f1c582` · **Source index:** 369 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 7 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong software engineering fundamentals and experience building production systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience with TypeScript, Rust, or a similar systems or application programming language.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Deep familiarity with modern software development tools, workflows, and engineering practices.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience using AI-assisted development tools and a strong intuition for their strengths, weaknesses, and emerging opportunities.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> A desire to own products and features end-to-end, from conception through launch and iteration.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong product judgment and a bias toward learning from real user feedback.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Creativity in reframing problems, challenging assumptions, and inventing new workflows rather than simply optimizing existing ones. The ideal candidate is someone who loves building developer tools, thinks deeply about how software gets built, and is excited by the opportunity to redefine those workflows from first principles in the age of AI.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

### 94. Host Systems Software Engineer

- **Posting:** https://jobs.ashbyhq.com/openai/87e5f8c3-3337-480a-9db2-e4cef5db909b
- **ID:** `87e5f8c3-3337-480a-9db2-e4cef5db909b` · **Source index:** 345 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 13 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience building low-level or performance-critical systems software.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong programming skills in C or C++, with proficiency using Python and Linux tooling for automation and debugging.

Topic signals: `automation`, `linux`, `python` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong Linux systems fundamentals and the ability to debug across hardware and software boundaries.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Hands-on experience in at least one relevant area, such as Linux kernel drivers, kernel networking, RDMA, PCIe, DMA, NIC software, accelerator software, or high-performance I/O.

Topic signals: `dns_network`, `linux` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Experience owning complex software projects from design through implementation, bring-up, and validation.

Topic signals: `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Ability to thrive in ambiguity, work across subsystem boundaries, and build systems from scratch.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — You might thrive in this role if you have:** (`EXPECTATION_CONTEXT`)

> Strong cross-functional communication skills.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R008 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Experience developing Linux kernel drivers or other OS-level performance-critical components.

Topic signals: `linux` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Familiarity with RDMA or RoCE, ibverbs, kernel networking, or congestion-control concepts such as ECN and DCQCN.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Experience with PCIe, DMA, peer-to-peer communication, SR-IOV, IOMMU, dma-buf, or related accelerator and I/O subsystems.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Experience bringing up accelerators, NICs, SoCs, or custom hardware platforms.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R012 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Experience profiling and optimizing high-throughput, low-latency systems.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Familiarity with Rust or experience using Rust for systems programming. To comply with U.S. export control laws and regulations, candidates for this role may need to meet certain legal status requirements as provided in those laws and regulations.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 95. Software Engineer - Data Aquisition (systems)

- **Posting:** https://jobs.ashbyhq.com/openai/70aaaafa-fe2f-4409-9a72-c0faf50d7d01
- **ID:** `70aaaafa-fe2f-4409-9a72-c0faf50d7d01` · **Source index:** 463 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 21 lines
- **Review flags:** `relocation_funding_not_established`

**R001 — WE EXPECT YOU TO:** (`EXPECTATION_CONTEXT`)

> Build and operate reliable infrastructure for research workloads and research-facing services.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — WE EXPECT YOU TO:** (`EXPECTATION_CONTEXT`)

> Support and improve systems across data infrastructure, processing, crawl and ingest, caching, search, observability, and clusterwide services.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — WE EXPECT YOU TO:** (`EXPECTATION_CONTEXT`)

> Improve cluster bootstrapping, provisioning, automation, and deployment workflows.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — WE EXPECT YOU TO:** (`EXPECTATION_CONTEXT`)

> Debug issues across networking, compute, storage, orchestration, and service reliability layers.

Topic signals: `dns_network` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — WE EXPECT YOU TO:** (`EXPECTATION_CONTEXT`)

> Build software and automation that reduce manual operational work and improve system reliability.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — WE EXPECT YOU TO:** (`EXPECTATION_CONTEXT`)

> Partner closely with researchers, infrastructure engineers, and service owners to understand system needs and translate them into durable solutions.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — WE EXPECT YOU TO:** (`EXPECTATION_CONTEXT`)

> Help evolve existing infrastructure toward more scalable, maintainable, and standard patterns.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — WE EXPECT YOU TO:** (`EXPECTATION_CONTEXT`)

> Take ownership of critical systems and drive work independently from problem definition through execution.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have strong systems fundamentals and understand how infrastructure scales in practice.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R010 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are comfortable with Linux, networking, Kubernetes, provisioning, and distributed systems operations.

Topic signals: `cloud`, `distributed_systems`, `dns_network`, `linux` · Evidence references: `WORK_BAAM`, `WORK_VIVINT`, `PROJECT_DNS`, `CERT_NETWORK` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Can write software to automate, debug, and improve infrastructure systems.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R012 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Have a strong execution mindset and can independently drive ambiguous infrastructure work.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R013 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Enjoy supporting a wide surface area of systems, from research tooling to platform services.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R014 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Are pragmatic about when to build custom systems versus using existing, well-supported tools.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R015 — YOU MIGHT THRIVE IN THIS ROLE IF YOU:** (`EXPECTATION_CONTEXT`)

> Care about building reliable systems that make researchers faster and reduce operational friction.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R016 — NICE TO HAVE:** (`PREFERRED_CONTEXT`)

> Experience with PXE boot, cluster provisioning, bare-metal infrastructure, or large-scale fleet management.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R017 — NICE TO HAVE:** (`PREFERRED_CONTEXT`)

> Experience operating Kubernetes or similar orchestration systems at scale.

Topic signals: `cloud` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R018 — NICE TO HAVE:** (`PREFERRED_CONTEXT`)

> Experience with infrastructure-as-code, CI/CD, observability, or deployment automation.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R019 — NICE TO HAVE:** (`PREFERRED_CONTEXT`)

> Experience supporting search infrastructure, data platforms, ingest systems, or large-scale research workflows.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R020 — NICE TO HAVE:** (`PREFERRED_CONTEXT`)

> Experience with Git-based workflows and internal developer tooling.

Topic signals: `automation` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R021 — NICE TO HAVE:** (`PREFERRED_CONTEXT`)

> Prior experience in environments where reliability, scale, and speed all matter.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 96. Software Engineer, Build Systems / CI

- **Posting:** https://jobs.ashbyhq.com/openai/202eb061-23d7-4a58-80c8-bc3b41e56d39
- **ID:** `202eb061-23d7-4a58-80c8-bc3b41e56d39` · **Source index:** 182 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_funding_not_established`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 97. Software Engineer, ChatGPT Infrastructure

- **Posting:** https://jobs.ashbyhq.com/openai/e6981259-c1d0-46de-8376-56bde28cfb10
- **ID:** `e6981259-c1d0-46de-8376-56bde28cfb10` · **Source index:** 154 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 10 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — Minimum Qualifications** (`STATED_REQUIREMENT_CONTEXT`)

> Experience building and operating large-scale distributed systems in production (high throughput, concurrency, and failure handling).

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — Minimum Qualifications** (`STATED_REQUIREMENT_CONTEXT`)

> Strong fundamentals in systems design, including caching, consistency, queueing/backpressure, and resilient dependency management.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — Minimum Qualifications** (`STATED_REQUIREMENT_CONTEXT`)

> Ability to reason about performance (latency distributions, tail behavior, bottlenecks) and translate analysis into concrete engineering work.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — Minimum Qualifications** (`STATED_REQUIREMENT_CONTEXT`)

> Track record of building platforms or shared infrastructure that improves velocity and correctness for other teams.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — Minimum Qualifications** (`STATED_REQUIREMENT_CONTEXT`)

> Excellent communication and collaboration skills—aligning on interfaces, navigating tradeoffs, and driving cross-team execution.

Topic signals: `customer_communication` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `WORK_VIVINT` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R006 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Experience designing paved roads / golden paths (frameworks, libraries, self-serve tooling) that shape engineering behavior at scale.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R007 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Deep understanding of reliability techniques: graceful degradation, circuit breakers, load shedding, rate limiting, and fault isolation.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Experience building systems for safe iteration: progressive delivery, correctness checks, automated rollout gates, and production validation.

Topic signals: `automation`, `testing` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R009 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Strong instincts for API and contract design—how to create interfaces that are stable, evolvable, and hard to misuse.

Topic signals: `api_integration` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Prior work that demonstrates “force multiplier” impact: enabling many teams via a small set of well-crafted primitives.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 98. Software Engineer, ChatGPT Shopping

- **Posting:** https://jobs.ashbyhq.com/openai/ca54cd23-2bcc-4327-bcb6-46d81ed414a8
- **ID:** `ca54cd23-2bcc-4327-bcb6-46d81ed414a8` · **Source index:** 406 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 6 lines
- **Review flags:** `relocation_funding_not_established`, `hybrid_not_utah_remote`

**R001 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Strong experience with modern frontend technologies (React, TypeScript, Next.js, or similar).

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Experience building scalable backend services using Python, Go, Node.js, Rust, or comparable technologies.

Topic signals: `python` · Evidence references: `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R003 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Familiarity with distributed systems, APIs, and cloud infrastructure.

Topic signals: `api_integration`, `cloud`, `distributed_systems` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R004 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Experience building highly interactive consumer products.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R005 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> Background working with AI, machine learning products, search, recommendations, personalization, or multimodal systems is a plus.

Topic signals: `machine_learning` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — Preferred Qualifications** (`PREFERRED_CONTEXT`)

> A track record of shipping products quickly while maintaining engineering quality. What Success Looks Like Successful engineers on this team combine strong technical execution with excellent product judgment. They move fluidly between prototyping and production systems, collaborate effectively across disciplines, and consistently deliver experiences that feel intuitive, elegant, and magical to users. They are excited by fast iteration, comfortable making decisions with imperfect information, and motivated by building products that redefine how people use AI every day. Why OpenAI At OpenAI, you'll work alongside some of the world's best researchers, engineers, designers, and product thinkers to build AI that benefits everyone. We value curiosity, ownership, humility, and a bias toward shipping impactful products. If you're excited about inventing new consumer experiences powered by frontier AI—and want to help shape the future of how millions of people interact with technology—we'd love to hear from you.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

### 99. Software Engineer, Cloud Agents

- **Posting:** https://jobs.ashbyhq.com/openai/f6278b60-dd42-4aa8-a3cd-c105f75ae8ae
- **ID:** `f6278b60-dd42-4aa8-a3cd-c105f75ae8ae` · **Source index:** 348 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_OFFICE_RELOCATION_NOT_STATED` (employer confirmation required)
- **Qualification extraction:** `NOT_EXTRACTED_REQUIRES_MANUAL_REVIEW`; 0 lines
- **Review flags:** `requirements_not_parsed_not_zero`, `relocation_funding_not_established`, `hybrid_not_utah_remote`

**No reliable structured qualification lines extracted; inspect the original posting manually.**

### 100. Software Engineer, Codex Cyber

- **Posting:** https://jobs.ashbyhq.com/openai/eefeb527-4e36-432e-a787-88e4672e29e1
- **ID:** `eefeb527-4e36-432e-a787-88e4672e29e1` · **Source index:** 407 · **Broad band:** `STRETCH_OR_LOGISTICS_REVIEW`
- **Geography:** `RELOCATION_NOT_CONFIRMED` / `US_WORK_ARRANGEMENT_UNKNOWN` (employer confirmation required)
- **Qualification extraction:** `EXTRACTED`; 15 lines
- **Review flags:** `relocation_funding_not_established`

**R001 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are an excellent software engineer with strong fundamentals and enough range to work across product, backend, infrastructure, and developer tooling.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R002 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Enjoy building high-quality product and platform experiences across the full stack.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R003 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are high-agency, low-drama, and comfortable owning features from concept to production in a fast-moving environment.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R004 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have built developer tools, workflow-heavy platforms, security products, internal infrastructure, or product features for technical users.

Topic signals: `automation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R005 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Have strong product instincts and care about making complex technical systems understandable and useful.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R006 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Are excited by security and AI. Direct experience in product security, application security, vulnerability research, defensive security, identity, SSO, or secure developer workflows is a plus, not a requirement.

Topic signals: `automation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R007 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Like ambiguous 0-to-1 work and can turn messy requirements into crisp, scalable systems. Goals &amp; impact

Topic signals: `distributed_systems` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R008 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Build AI-native security products that help users find and fix important vulnerabilities in real software systems before attackers do.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R009 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Increase the usefulness and trustworthiness of Codex Security by turning research insights into dependable workflows, product surfaces, platform controls, and remediation tooling.

Topic signals: `automation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R010 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Help define a new category of security tooling where models reason over real code, validate exploitability, and propose fixes directly in developer workflows. Key technical challenges

Topic signals: `automation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R011 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Combining model outputs, security analysis, and user workflows into one cohesive product experience.

Topic signals: `automation`, `security` · Evidence references: `WORK_ZION`, `WORK_BAAM`, `PROJECT_CRM`, `PROJECT_JIRA`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R012 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Designing high-confidence validation and remediation flows that distinguish real issues from noisy or speculative findings.

Topic signals: `testing` · Evidence references: `WORK_BAAM`, `PROJECT_JIRA`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R013 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Scaling product and platform infrastructure for large repositories, complex enterprise environments, and long-running analyses.

Topic signals: none · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

**R014 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Creating developer-friendly interfaces and APIs that make advanced security capabilities understandable and actionable.

Topic signals: `api_integration`, `security` · Evidence references: `WORK_BAAM`, `PROJECT_DNS`, `SKILLS_LIST`, `PROJECT_PROOFLOOP_STAGES1TO5` · Assessment: **TOPIC_OVERLAP_NOT_REQUIREMENT_PROOF**

**R015 — You might thrive in this role if you:** (`EXPECTATION_CONTEXT`)

> Building platform controls and internal systems that help Codex Cyber move quickly while meeting OpenAI's bar for safety, security, and reliability.

Topic signals: `security` · Evidence references: none · Assessment: **NO_PROFILE_TOPIC_EVIDENCE**

## Limitations

- Only selected 100 reviewed, not all 816
- Plain-text section extraction can miss nonstandard headings or qualifications outside detected sections
- Keyword topic overlap does not establish a full requirement match
- Resume claims are not independently verified
- Duration, credentials and production scope require manual assessment
- Relocation offers do not establish financial sufficiency
- Snapshot membership is not live job availability
- No top-five ranking at this stage
