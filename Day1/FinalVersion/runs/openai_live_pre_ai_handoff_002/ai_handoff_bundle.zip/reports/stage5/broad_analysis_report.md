# ProofLoop Stage 5 — Broad Role Analysis

- **Status:** PASS
- **Board:** `openai`
- **Analyzed:** 816 postings
- **Database SHA-256:** `abcfb60e1674a703a34c4e6613cc54552220bac32e313ca8baa13fa4ed447be3`
- **Profile SHA-256:** `2197343991bf93b6b56ed66eb67e8afed7f65674e7466b5799fcf4d96782f20d`
- **Review pool:** 100 (maximum 100)

## Triage bands

| Band | Count |
|---|---:|
| DEEP_REVIEW_PRIORITY | 100 |
| HOLD_WITH_REASONS | 566 |
| STRETCH_OR_LOGISTICS_REVIEW | 150 |

## Location classifications

| Category | Count |
|---|---:|
| LOCATION_UNKNOWN | 3 |
| NON_US_LOCATIONS_ONLY | 167 |
| US_OFFICE_RELOCATION_NOT_STATED | 229 |
| US_RELOCATION_ASSISTANCE_STATED | 257 |
| US_REMOTE_ADVERTISED | 17 |
| US_REMOTE_LOCATION_REVIEW | 18 |
| US_WORK_ARRANGEMENT_UNKNOWN | 125 |

## Sales and technical classifications

| Classification | Count |
|---|---:|
| NO_STRONG_SALES_EVIDENCE | 649 |
| SALES_CONTEXT_REVIEW | 118 |
| SALES_PRIMARY_EVIDENCE | 49 |
| HANDS_ON_EVIDENCE | 299 |
| TECHNICAL_CORE_UNCONFIRMED | 517 |

## Candidate review queue (not a ranking)

| Job | Band | Source |
|---|---|---|
| Software Engineer, Infrastructure Security | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/98ad9beb-4f91-496c-bd16-ac0b2a8d5bb2) |
| Security Engineer, Infrastructure Security | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/f51f750f-a737-4441-8f96-30133a2a8049) |
| Principal Software Engineer, Infrastructure Security | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/ace42c6d-8663-4b30-9337-ec70cf071d73) |
| Principal Security Engineer, Infrastructure Security | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/8f1b8c6b-b414-4026-a434-6ca32c3b3e0d) |
| Data Center Compute, OpenHouse Savannah 2026 | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/6ba0ce24-ad32-4c3b-b49c-b373be9a8480) |
| Industrial Compute | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/6d7ece77-bf25-4f5e-9a84-c5ce26e18c37) |
| Senior Technical Program Manager - Security | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/c414f15f-60c4-40b5-a896-d2ad6c7f4415) |
| Forward Deployed Security Engineer | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/89d61ae8-1ce1-4187-9edd-da8029979e41) |
| Software Engineer, Manufacturing Infrastructure | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/3b08148d-085e-4835-9934-1b7f60e0fdce) |
| Software Engineer, Resilience Engineering | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/1faee5e7-3b2f-4d8c-9a6f-ff0f2a4a42a7) |
| Software Engineer, Search Infrastructure | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/7caed1e8-c6f6-4569-9d45-2d7a7a56a025) |
| System Software Engineer, Consumer Devices | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/20f525b7-f958-4c95-a055-f914ab3adb95) |
| Systems Software Engineer, Management Plane | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/21229750-8bd1-4134-a20e-2a8922b88806) |
| Systems Software Engineer, Security, First Party Hardware | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/1c48f39f-60ea-4636-87ed-8b4b4f5243e5) |
| AI Support Engineer, Government - San Francisco, CA | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/48993416-b5f5-4c3f-b7c8-b8ca7c2395e0) |
| AI Support Engineer, Government - Washington, D.C. | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/6d1d835d-5882-4191-b78e-fd04a4c05f11) |
| Connectivity Software Engineer, Consumer Devices | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/9b2c68f2-5ce8-44f9-a30c-d8016ac66d86) |
| IT Support Specialist | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/49ae54dc-3d33-4107-8112-63fac1ee86ca) |
| Software Engineer,  ML Systems &amp; Training Architecture | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/9117987a-7a59-449e-a702-89e8d0e8cb60) |
| Software Engineer, Ads Manager | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/5a4eed17-29d5-41cb-856e-09bfdaffe017) |
| Software Engineer, Core Services | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/21bfde35-ffec-42d2-a2c6-8a03dad789d5) |
| Software Engineer, Infrastructure - Core Experimentation | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/823a05bf-33fb-4d94-9dd8-571723d27b1a) |
| Camera Software Engineer, Consumer Devices | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/1dc05fc7-ceb7-4827-a905-9d1beb77a4a0) |
| Forward Deployed Software Engineer - NYC | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/533c0fc9-b773-476d-9f96-a0528efbab0e) |
| Forward Deployed Software Engineer - Seattle | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/7b90b83c-ec28-4e65-a235-6675e37b91c3) |
| Forward Deployed Software Engineer - SF | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/00207abc-49b7-465c-a219-f7c1140f8047) |
| Full Stack Software Engineer, Cybersecurity Products | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/88654e7f-4e23-4e75-8e54-18c10d09b093) |
| Security Engineer, Application Security | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/0322d6d8-6588-4209-a304-83e768063a25) |
| Security Engineer, Application Security | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/1e110226-448a-4c0b-b0e4-d0f5df579fbf) |
| Security Engineer, Application Security | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/ec5a5d98-6314-44d9-9466-8d4d7ee866f6) |
| Software Engineer, Ads Integrity | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/596e543a-0ab9-471e-a1ff-40fd55c74fce) |
| Software Engineer, Agent Infrastructure | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/c1316397-25bb-4add-9e9d-0e3ea8ba929a) |
| Software Engineer, Cloud Infrastructure | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/12342ebb-dcd4-45e2-b875-fc5447fdb7d8) |
| Software Engineer, Data Infrastructure | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/f763c6b3-5167-4a67-b691-4c3fa2c44156) |
| Software Engineer, Developer Productivity | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/2cba0d45-7a4f-4f38-ac73-3f8633bf0349) |
| Software Engineer, Fleet Management | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/7809102e-e82a-4678-bf7c-221de8acc0d6) |
| Software Engineer, Monetization Delivery | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/a4ea79c8-e79f-4126-8c1f-032289024961) |
| Software Engineer, Monetization Product &amp; Platform | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/c51e48ce-31ad-4176-a6d5-4a785b44ab73) |
| Software Engineer, Plugin Developer Platform | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/71838fdf-4476-490c-81b6-4bf0746f6774) |
| Software Engineer, Plugin Ecosystem | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/e42305bf-2266-4dff-82ad-42be7ddac495) |
| Software Engineer, Privacy Engineering | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/07153f7c-7e8b-4283-a879-cb07a224e083) |
| Software Engineer, Private Computing | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/0f887fe6-39f4-44f6-8ee5-230c3002f0d7) |
| Systems Integration Engineer, Build Systems \| Consumer Devices | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/9104a37c-6ae0-499b-a2f7-2785e63b5f0c) |
| Android Systems Engineer, Consumer Devices | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/b08126cc-8134-45f0-aeb3-4b00e96547de) |
| Data Engineer | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/fc5bbc77-a30c-4e7a-9acc-8a2e748545b4) |
| Full Stack Software Engineer, Sales Platform | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/1f7c6071-ad3a-4903-9b05-4684f5c1a7c8) |
| Personnel Security Specialist | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/2ee660bf-1911-4619-9282-751cd9fc5c61) |
| Software Engineer, Ad Formats | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/0b212a4a-6709-4da8-b59d-283a9bbf812e) |
| Software Engineer, Collective Communication | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/340c0c22-8d8f-4232-b17e-f642b64c25c3) |
| Software Engineer, Distributed Data Systems - Robotics | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/da07ba71-81fd-47c7-adb1-2b2d1eaed325) |
| Software Engineer, Research - Human Data | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/4d6a5951-9838-434c-830a-22cb938ea228) |
| Software Engineer, Research Developer Productivity | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/e6d5ca02-f30b-4ac5-a69d-c947efb430f9) |
| Software Engineer, Shop/Feed Ads | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/4d7145cf-ef4e-4a39-b1ef-b58e4e5c06d2) |
| Forward Deployed Software Engineer, Gov | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/db5a708d-1d7a-4aa3-8dd3-0d0423b6b69f) |
| Full Stack Software Engineer, Product Explorations | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/4d1ede8c-3d4c-4503-8408-81e4b68c5c91) |
| Software Engineer, Fleet Infrastructure | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/a58add97-1968-4d5c-b504-ab62bea12df3) |
| Senior Support Engineer - San Francisco | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/5431666c-530b-49c0-b67e-32477f9eaf5e) |
| Senior Software Engineer - Research Platform, Consumer Devices | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/6d9925f4-3d0a-4710-8304-032d0080d12d) |
| Senior Staff Software Engineer, Identity Infrastructure Engineering | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/72a58872-70e2-4340-a259-e9bea3596883) |
| Network Engineer | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/9f78c41f-8d39-46c9-b9c3-c3b075905b24) |
| Applied AI Engineer, Plugins | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/ca9e0aeb-6df1-4b73-8ec0-2e9e124712f1) |
| Networking Operating System Firmware Engineer | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/f6b9903c-9034-436b-a4ec-4c8643a6d0dd) |
| Applied AI Engineer, API Platform, Digital Natives | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/3254f6a7-6353-4a77-beec-f37b832c99ae) |
| Applied AI Engineer, API Platform, Digital Natives | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/5c3a17db-62f1-4145-93b0-2f207d4d4af8) |
| Applied AI Engineer, Enterprise | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/01091aed-427d-4e10-8cdb-fb500cf55bb9) |
| Data Engineering Manager, Growth &amp; Revenue | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/acbf80cd-20a7-47fe-aaf9-3e9224d1570c) |
| Data Scientist, Business | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/fc72784d-f925-4f8d-aebc-eee72e7bf55c) |
| Early Access Deployment Engineer | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/ee6b7ece-ffcb-4546-8b4c-ef755ec21c14) |
| Firmware Engineer, RTOS, Consumer Devices | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/2710d0c7-8f1c-4e1a-bf7a-4000fc5a8d68) |
| Product Marketing Manager, Cybersecurity | DEEP_REVIEW_PRIORITY | [posting](https://jobs.ashbyhq.com/openai/9c990e11-a5fb-4c6d-ab83-ede32839e78e) |
| Dedicated Support Engineer - San Francisco | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/2348230a-295f-434d-9b16-653e01ddbd0b) |
| Software Engineer, Compute Infrastructure | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/ca300a6d-a2a7-4580-aad7-323fbdfee7b1) |
| AI Support Engineer - San Francisco | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/1a979fd4-1bce-484e-a416-aed2810677a6) |
| AI Support Engineer - San Francisco (Weekend Shift) | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/99f823a1-66ec-44bd-ba30-d3645aa49d74) |
| Operating Systems Engineer \| Consumer Devices | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/efed424b-e025-400f-8ac3-73e962b85751) |
| Operating Systems Engineer, Connectivity &amp; Networking \| Consumer Devices | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/c5f39beb-dc8a-4f43-a156-28754d306f64) |
| Software Engineer, API Enterprise Controls | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/4c0a6cb6-d365-4e5b-bdff-c093d951026d) |
| Software Engineer, API Multicloud | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/4070d52e-0263-4cd5-9107-052b4ecc1209) |
| Software Engineer, Codex Core Agents | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/7ade7a12-845c-4e3a-af23-c028420bd181) |
| Software Engineer, Compute Foundations Systems | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/770d5c3f-4e72-4b49-aec4-d444e8ad7a64) |
| Software Engineer, Enterprise Verticals | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/3229b152-015f-49ad-9921-9c9de95570c8) |
| Software Engineer, GPT Infrastructure | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/f3ddd41c-541f-485e-90d6-86c26e018e9f) |
| Software Engineer, Healthcare | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/4923fd3e-acf2-4551-91ad-5a92ca81455b) |
| Software Engineer, Implicit Signals | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/c7bcdaec-9714-44b0-8ba8-adc824594b54) |
| Software Engineer, Infrastructure - Analytics Platform | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/e44bfa94-0b82-4d0c-b224-02155b76eea9) |
| Software Engineer, Monetization Data Systems | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/d2aad13c-6ed0-4905-ae12-8ea2397b190c) |
| AI Support Engineer, Biosciences - San Francisco | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/759dd316-cbe9-4e73-af57-808502568b29) |
| AI Systems Engineer, Codex Agents | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/de06790a-7243-4e33-a6f1-e7bd34009588) |
| Applied AI Software Engineer, GTM Growth Engineering | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/38e3c4bf-a632-405e-9619-b87382ca2472) |
| Full Stack Software Engineer, API Experience | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/66288824-8b77-4774-bc57-6825d3e6221e) |
| Full Stack Software Engineer, ChatGPT Finances | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/39e06ef9-5e62-425d-81e2-e8690188011f) |
| Full Stack Software Engineer, ChatGPT ImageGen | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/6b47238e-025a-4350-b270-2f3564002fcc) |
| Full Stack Software Engineer, Codex | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/5ebd5f66-75db-4a96-8d39-babc14f1c582) |
| Host Systems Software Engineer | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/87e5f8c3-3337-480a-9db2-e4cef5db909b) |
| Software Engineer - Data Aquisition (systems) | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/70aaaafa-fe2f-4409-9a72-c0faf50d7d01) |
| Software Engineer, Build Systems / CI | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/202eb061-23d7-4a58-80c8-bc3b41e56d39) |
| Software Engineer, ChatGPT Infrastructure | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/e6981259-c1d0-46de-8376-56bde28cfb10) |
| Software Engineer, ChatGPT Shopping | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/ca54cd23-2bcc-4327-bcb6-46d81ed414a8) |
| Software Engineer, Cloud Agents | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/f6278b60-dd42-4aa8-a3cd-c105f75ae8ae) |
| Software Engineer, Codex Cyber | STRETCH_OR_LOGISTICS_REVIEW | [posting](https://jobs.ashbyhq.com/openai/eefeb527-4e36-432e-a787-88e4672e29e1) |

## Boundaries

All source roles are preserved in the JSON report; the review queue is a deterministic triage subset, not the five best opportunities.
An API isRemote=true flag does **not** prove Utah-remote eligibility, especially where workplaceType=Hybrid.
Relocation wording is an advertisement, not confirmed personal financial coverage.
Sales and technical classifications are heuristic and contain false positive/negative risk.
Qualification section extraction is incomplete when headings vary; experience years are not automatically required or satisfied.
This stage does not compare a verified résumé or select final application targets.
