# Building My Way Into AI — ProofLoop Stage 8 AI Review Protocol

## Files and provenance
- `source/all_816_source_roles.jsonl`: all 816 records with ORIGINAL employer-provided fields (including full descriptions and application URLs), canonical projections, source indices and provenance. This is snapshot data, NOT live vacancy confirmation.
- `reports/stage5/*`: complete Stage 5 broad review and its 100-role selection.
- `reports/stage6/*`: full 100-role deep dossier and summary, with provisional candidate evidence IDs.
- `reports/stage7/*`: comparative analysis, full-corpus audit, matrix, input manifest.
- `reports/stage8/*`: independent audit findings and review flags.
- `candidate/candidate_evidence_public.json`: contact-sanitized, full structured candidate evidence from the ORIGINAL Stage 6 profile.
- `candidate/PROJECT_PROOFLOOP_UPDATE.json`: additive project update to Stage 8, not professional work history.
- `candidate/resume_professional_claims.md`: fuller candidate résumé content without direct contact details, when `--resume-claims` is provided.
- `handoff_manifest.json`: SHA-256 and bytes of every file in this archive other than itself.

## AI instructions (not automatic authorization to submit applications)
1. Check the manifest hashes and reconcile contradictions between source text and any heuristic report. Never blindly assume classification correctness.
2. Read descriptions from all 816 roles as needed; focus deeply on the 100 dossiers **and** 175 out-of-pool recall leads. Check other roles if evidence warrants it; avoid assuming unflagged equals unqualified.
3. Audit requirement extraction, particularly supplementary headings, minimum versus preferred requirements, complex OR/AND alternatives, and embedded-heading artifacts.
4. Read the included candidate JSON evidence, the ProofLoop project addendum, AND the résumé claims Markdown (when present). Treat résumé claims as **unverified**, and do not infer proficiency, professional tenure or independent authorship from skill keywords or the collaborative ProofLoop project. Clarify uncertainties with the user before firm qualification judgments.
5. Compare practical opportunity and verified qualifications separately. The user resides in southern Utah; remote metadata alone is not proof of Utah eligibility. Relocation assistance, when stated, has unconfirmed dollar value and eligibility.
6. Avoid sales-primary opportunities unless the user changes this constraint; interpret technical roles adjacent to sales based on actual duties.
7. Check current availability, listed qualifications and work arrangements at the employer's official posting before submitting any application. Time-stamped URLs are historical evidence, not confirmation.
8. Challenge the Stage 5–7 screens; preserve rejected alternatives and dissenting reasoning. No arbitrary numerical scores or asserted probability of hiring.
9. Recommend five defensible applications with alternatives and explicit gaps, not necessarily the five best technical matches; the **one** shared Building My Way Into AI / ProofLoop technical project remains the founding targeted project for Attempt #001.
10. Do not send applications without user review and approval. Record decisions, reasons, dates and observed employer requirements as a traceable audit trail.

## Candidate evidence present; personal contact details absent
This archive INCLUDES the complete structured résumé-derived qualification evidence from Stage 6 (sanitized at the field/contact level), plus a separately sourced Stage 1–8 project update and, when provided, a fuller contact-redacted résumé transcription. It excludes the raw private input bytes, original résumé PDF and direct contact details such as email, phone, postal address and profile links. The full original evidence SHA-256 is preserved for provenance. Review the actual exported candidate file before publishing, because employer names, dated work history and credential claims can still be personally identifying. The user has requested this professional content in the shareable archive; no job application is authorized by the archive.

## Open quality notes
Stage 7's README sample contained an outdated requirement-line count. The current machine-generated reports are authoritative for the current run; inspect the Stage 8 audit flags for other limitations.
